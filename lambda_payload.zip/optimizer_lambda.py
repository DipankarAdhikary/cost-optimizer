import boto3
import os
import logging
import json
from datetime import datetime, timezone, timedelta
from botocore.exceptions import ClientError, NoCredentialsError, PartialCredentialsError
from statistics import mean

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# --- Configuration ---
DRY_RUN = os.environ.get('DRY_RUN', 'true').lower() == 'true'
TARGET_REGIONS_STR = os.environ.get("TARGET_REGIONS", "us-east-1")
TARGET_REGIONS = [region.strip() for region in TARGET_REGIONS_STR.split(',') if region.strip()]
DEFAULT_REGION = os.environ.get('AWS_REGION', 'us-east-1')
EXCLUDE_TAG_KEY = os.environ.get('OPTIMIZATION_EXCLUDE_TAG_KEY', 'cost-optimizer-exclude')
EXCLUDE_TAG_VALUE = os.environ.get('OPTIMIZATION_EXCLUDE_TAG_VALUE', 'true')

# EC2 Config
ENABLE_EC2_TERMINATION = os.environ.get('ENABLE_EC2_TERMINATION', 'true').lower() == 'true'
EC2_STOPPED_DAYS_THRESHOLD = int(os.environ.get('EC2_STOPPED_DAYS_THRESHOLD', '7')) # MINS FOR TEST
ENABLE_EC2_OPTIMIZATION_REPORTING = os.environ.get('ENABLE_EC2_OPTIMIZATION_REPORTING', 'true').lower() == 'true'
EC2_RIGHTSIZE_CHECK_DAYS = int(os.environ.get('EC2_RIGHTSIZE_CHECK_DAYS', '14'))

# EBS Config
ENABLE_EBS_GP2_TO_GP3_CONVERSION = os.environ.get('ENABLE_EBS_GP2_TO_GP3_CONVERSION', 'true').lower() == 'true'
ENABLE_EBS_GP2_TO_GP3_CONVERSION_FOR_ROOT = os.environ.get('ENABLE_EBS_GP2_TO_GP3_CONVERSION_FOR_ROOT', 'false').lower() == 'true'
ENABLE_EBS_AVAILABLE_VOLUME_DELETION = os.environ.get('ENABLE_EBS_AVAILABLE_VOLUME_DELETION', 'true').lower() == 'true'
ENABLE_EBS_SNAPSHOT_DELETION = os.environ.get('ENABLE_EBS_SNAPSHOT_DELETION', 'true').lower() == 'true'
EBS_SNAPSHOT_RETENTION_DAYS = int(os.environ.get('EBS_SNAPSHOT_RETENTION_DAYS', '30')) # MINS FOR TEST
ENABLE_EBS_IDLE_VOLUME_REPORTING = os.environ.get('ENABLE_EBS_IDLE_VOLUME_REPORTING', 'true').lower() == 'true'
EBS_IDLE_TIME_THRESHOLD_PERCENT = int(os.environ.get('EBS_IDLE_TIME_THRESHOLD_PERCENT', '99'))
EBS_IDLE_CHECK_DAYS = int(os.environ.get('EBS_IDLE_CHECK_DAYS', '14')) # MINS FOR TEST

# ELB Config
ENABLE_ELB_DELETION = os.environ.get('ENABLE_ELB_DELETION', 'true').lower() == 'true'
ELB_IDLE_DAYS_THRESHOLD = int(os.environ.get('ELB_IDLE_DAYS_THRESHOLD', '30')) # MINS FOR TEST

# EIP Config
ENABLE_EIP_RELEASE = os.environ.get('ENABLE_EIP_RELEASE', 'true').lower() == 'true'
UNATTACHED_EIP_PRICE_HOURLY = 0.005

# CW Logs Config
ENABLE_CW_LOG_GROUP_RETENTION_MANAGEMENT = os.environ.get('ENABLE_CW_LOG_GROUP_RETENTION_MANAGEMENT', 'true').lower() == 'true'
CW_LOG_GROUP_RETENTION_PROD_UAT_DAYS = int(os.environ.get('CW_LOG_GROUP_RETENTION_PROD_UAT_DAYS', '90'))
CW_LOG_GROUP_RETENTION_DEV_DAYS = int(os.environ.get('CW_LOG_GROUP_RETENTION_DEV_DAYS', '7'))
CW_LOG_GROUP_RETENTION_DEFAULT_DAYS = int(os.environ.get('CW_LOG_GROUP_RETENTION_DEFAULT_DAYS', '30'))
ENVIRONMENT_TAG_KEY = os.environ.get('ENVIRONMENT_TAG_KEY', 'Environment')
ENV_VALUES_PROD = [v.strip().lower() for v in os.environ.get('ENVIRONMENT_VALUES_PROD', 'prod,production').split(',')]
ENV_VALUES_UAT = [v.strip().lower() for v in os.environ.get('ENVIRONMENT_VALUES_UAT', 'uat,staging,stage,test').split(',')]
ENV_VALUES_DEV = [v.strip().lower() for v in os.environ.get('ENVIRONMENT_VALUES_DEV', 'dev,development').split(',')]
CW_LOG_STORAGE_PRICE_GB_MONTH = 0.03

# CW Alarms Config
ENABLE_CW_INSUFFICIENT_DATA_ALARM_REPORTING = os.environ.get('ENABLE_CW_INSUFFICIENT_DATA_ALARM_REPORTING', 'true').lower() == 'true'
CW_ALARM_INSUFFICIENT_DATA_DAYS_THRESHOLD = int(os.environ.get('CW_ALARM_INSUFFICIENT_DATA_DAYS_THRESHOLD', '30')) # MINS FOR TEST

# RDS Config
ENABLE_RDS_BACKUP_RETENTION_ADJUSTMENT = os.environ.get('ENABLE_RDS_BACKUP_RETENTION_ADJUSTMENT', 'true').lower() == 'true'
RDS_MAX_BACKUP_RETENTION_DAYS = int(os.environ.get('RDS_MAX_BACKUP_RETENTION_DAYS', '7'))
ENABLE_RDS_MANUAL_SNAPSHOT_DELETION = os.environ.get('ENABLE_RDS_MANUAL_SNAPSHOT_DELETION', 'true').lower() == 'true'
RDS_MANUAL_SNAPSHOT_RETENTION_DAYS = int(os.environ.get('RDS_MANUAL_SNAPSHOT_RETENTION_DAYS', '7')) # MINS FOR TEST
ENABLE_RDS_LOW_CPU_REPORTING = os.environ.get('ENABLE_RDS_LOW_CPU_REPORTING', 'true').lower() == 'true'
RDS_LOW_CPU_THRESHOLD_PERCENT = int(os.environ.get('RDS_LOW_CPU_THRESHOLD_PERCENT', '10'))
RDS_RIGHTSIZE_CHECK_DAYS = int(os.environ.get('RDS_RIGHTSIZE_CHECK_DAYS', '14')) # MINS FOR TEST
RDS_SNAPSHOT_PRICE_GB_MONTH = 0.05

# S3 Config
ENABLE_S3_OBJECT_DELETION = os.environ.get('ENABLE_S3_OBJECT_DELETION', 'false').lower() == 'true'
S3_CLEANUP_TAG_KEY = os.environ.get('S3_CLEANUP_TAG_KEY', 'cost-optimizer-cleanup-objects')
S3_CLEANUP_TAG_VALUE = os.environ.get('S3_CLEANUP_TAG_VALUE', 'true')
S3_OBJECT_AGE_DAYS_THRESHOLD = int(os.environ.get('S3_OBJECT_AGE_DAYS_THRESHOLD', '30')) # MINS FOR TEST
S3_STANDARD_PRICE_GB_MONTH = 0.023

# Lambda Config
ENABLE_LAMBDA_IDLE_REPORTING = os.environ.get('ENABLE_LAMBDA_IDLE_REPORTING', 'true').lower() == 'true'
LAMBDA_IDLE_DAYS_THRESHOLD = int(os.environ.get('LAMBDA_IDLE_DAYS_THRESHOLD', '30')) # USE DAYS
LAMBDA_IDLE_INVOCATION_THRESHOLD = int(os.environ.get('LAMBDA_IDLE_INVOCATION_THRESHOLD', '5'))

# EKS Config
ENABLE_EKS_UNUSED_CLUSTER_REPORTING = os.environ.get('ENABLE_EKS_UNUSED_CLUSTER_REPORTING', 'true').lower() == 'true'
EKS_CONTROL_PLANE_PRICE_HOURLY = 0.10

# NAT Gateway Config
ENABLE_NAT_GATEWAY_IDLE_REPORTING = os.environ.get('ENABLE_NAT_GATEWAY_IDLE_REPORTING', 'true').lower() == 'true'
NAT_IDLE_CHECK_DAYS = int(os.environ.get('NAT_IDLE_CHECK_DAYS', '30')) # USE DAYS
NAT_BYTES_PROCESSED_THRESHOLD = int(os.environ.get('NAT_BYTES_PROCESSED_THRESHOLD', 1 * 1024**3))
NAT_GW_PRICE_HOURLY = 0.045

# Security Groups Config
ENABLE_UNUSED_SECURITY_GROUP_REPORTING = os.environ.get('ENABLE_UNUSED_SECURITY_GROUP_REPORTING', 'true').lower() == 'true'


# --- Helper Functions ---

def is_excluded(tags):
    if not tags: return False
    tag_list = tags
    if isinstance(tags, dict): tag_list = [{'Key': k, 'Value': v} for k, v in tags.items()]
    if not isinstance(tag_list, list): logger.warning(f"Unexpected tag format: {type(tag_list)}."); return False
    for tag in tag_list:
        if isinstance(tag, dict) and tag.get('Key') == EXCLUDE_TAG_KEY and tag.get('Value') == EXCLUDE_TAG_VALUE: return True
    return False

def get_tag_value(tags, key):
    if not tags or not key: return None
    tag_list = tags
    if isinstance(tags, dict): tag_list = [{'Key': k, 'Value': v} for k, v in tags.items()]
    if not isinstance(tag_list, list): logger.warning(f"Unexpected tag format: {type(tag_list)}."); return None
    for tag in tag_list:
       if isinstance(tag, dict) and tag.get('Key') == key: return tag.get('Value')
    return None

# --- Pricing Helper Functions ---

def get_ec2_instance_price(instance_type, region):
    
    pricing_client = boto3.client('pricing', region_name='us-east-1')
    region_mapping = { 'us-east-1': 'US East (N. Virginia)', 'eu-west-1': 'EU (Ireland)' }
    location = region_mapping.get(region, region)
    try:
        response = pricing_client.get_products( ServiceCode='AmazonEC2', Filters=[ {'Type': 'TERM_MATCH', 'Field': 'instanceType', 'Value': instance_type}, {'Type': 'TERM_MATCH', 'Field': 'location', 'Value': location}, {'Type': 'TERM_MATCH', 'Field': 'operatingSystem', 'Value': 'Linux'}, {'Type': 'TERM_MATCH', 'Field': 'preInstalledSw', 'Value': 'NA'}, {'Type': 'TERM_MATCH', 'Field': 'tenancy', 'Value': 'Shared'}, {'Type': 'TERM_MATCH', 'Field': 'capacitystatus', 'Value': 'Used'} ], MaxResults=1 )
        price_list = response.get('PriceList', [])
        if price_list:
            price_item = json.loads(price_list[0]); terms = price_item.get('terms', {}).get('OnDemand', {})
            if terms: term_key = list(terms.keys())[0]; price_dimensions = terms[term_key].get('priceDimensions', {}); price_key = list(price_dimensions.keys())[0]; price_value = price_dimensions[price_key].get('pricePerUnit', {}).get('USD')
            if price_value: return float(price_value)
        logger.warning(f"Could not parse EC2 price for {instance_type} in {region}")
        return None
    except (ClientError, KeyError, IndexError, ValueError, TypeError, json.JSONDecodeError) as e:
        logger.error(f"Error fetching/parsing EC2 pricing for {instance_type} in {region}: {e}")
        return None

def get_ebs_price(volume_type, region):
    
     pricing_client = boto3.client('pricing', region_name='us-east-1')
     region_mapping = { 'us-east-1': 'US East (N. Virginia)', 'eu-west-1': 'EU (Ireland)' }
     location = region_mapping.get(region, region)
     try:
         response = pricing_client.get_products( ServiceCode='AmazonEC2', Filters=[ {'Type': 'TERM_MATCH', 'Field': 'volumeApiName', 'Value': volume_type}, {'Type': 'TERM_MATCH', 'Field': 'location', 'Value': location} ], MaxResults=1 )
         price_list = response.get('PriceList', [])
         if price_list:
             price_item = json.loads(price_list[0]); terms = price_item.get('terms', {}).get('OnDemand', {})
             if terms: term_key = list(terms.keys())[0]; price_dimensions = terms[term_key].get('priceDimensions', {}); price_key = list(price_dimensions.keys())[0]; price_value = price_dimensions[price_key].get('pricePerUnit', {}).get('USD')
             if price_value: return float(price_value)
         logger.warning(f"Could not parse EBS price for {volume_type} in {region}")
         return None
     except (ClientError, KeyError, IndexError, ValueError, TypeError, json.JSONDecodeError) as e:
         logger.error(f"Error fetching/parsing EBS pricing for {volume_type} in {region}: {e}")
         return None

def get_ebs_snapshot_price(region):
     # ... (implementation from previous full code) ...
     pricing_client = boto3.client('pricing', region_name='us-east-1')
     region_mapping = { 'us-east-1': 'US East (N. Virginia)', 'eu-west-1': 'EU (Ireland)' }
     location = region_mapping.get(region, region)
     region_prefix_map = { 'us-east-1': 'USE1', 'eu-west-1': 'EU' }
     usage_type_prefix = region_prefix_map.get(region, region.upper().replace('-', ''))
     usage_type = f"{usage_type_prefix}-SnapshotUsage"
     price_value = None
     try:
         response = pricing_client.get_products( ServiceCode='AmazonEC2', Filters=[ {'Type': 'TERM_MATCH', 'Field': 'productFamily', 'Value': 'Storage Snapshot'}, {'Type': 'TERM_MATCH', 'Field': 'location', 'Value': location}, {'Type': 'TERM_MATCH', 'Field': 'usagetype', 'Value': usage_type} ], MaxResults=1 )
         price_list = response.get('PriceList', [])
         if price_list:
              price_item = json.loads(price_list[0]); terms = price_item.get('terms', {}).get('OnDemand', {})
              if terms: term_key = list(terms.keys())[0]; price_dimensions = terms[term_key].get('priceDimensions', {}); price_key = list(price_dimensions.keys())[0]; price_str = price_dimensions[price_key].get('pricePerUnit', {}).get('USD')
              if price_str: price_value = float(price_str)
         if price_value is None:
             logger.warning(f"Snapshot price not found with usage type {usage_type}, trying generic filter.")
             response = pricing_client.get_products( ServiceCode='AmazonEC2', Filters=[ {'Type': 'TERM_MATCH', 'Field': 'productFamily', 'Value': 'Storage Snapshot'}, {'Type': 'TERM_MATCH', 'Field': 'location', 'Value': location} ], MaxResults=1 )
             price_list = response.get('PriceList', [])
             if price_list:
                  price_item = json.loads(price_list[0]); terms = price_item.get('terms', {}).get('OnDemand', {})
                  if terms: term_key = list(terms.keys())[0]; price_dimensions = terms[term_key].get('priceDimensions', {}); price_key = list(price_dimensions.keys())[0]; price_str = price_dimensions[price_key].get('pricePerUnit', {}).get('USD')
                  if price_str: price_value = float(price_str)
         if price_value is None: logger.warning(f"Could not parse EBS snapshot price for {region}")
         return price_value
     except (ClientError, KeyError, IndexError, ValueError, TypeError, json.JSONDecodeError) as e:
         logger.error(f"Error fetching/parsing EBS snapshot pricing for {region}: {e}")
         return None

def get_elb_price(lb_type, region):
     # ... (implementation from previous full code) ...
     pricing_client = boto3.client('pricing', region_name='us-east-1')
     region_mapping = { 'us-east-1': 'US East (N. Virginia)', 'eu-west-1': 'EU (Ireland)' }
     location = region_mapping.get(region, region)
     product_family_map = { 'application': 'Load Balancer-Application', 'network': 'Load Balancer-Network', 'gateway': 'Load Balancer-Gateway' }
     product_family = product_family_map.get(lb_type)
     if not product_family: return None
     region_prefix_map = { 'us-east-1': 'USE1', 'eu-west-1': 'EU' }
     usage_type_prefix = region_prefix_map.get(region, region.upper().replace('-', ''))
     usage_type_attempts = [ f"{usage_type_prefix}-LoadBalancerUsage", "LoadBalancerUsage" ]
     price_value = None
     try:
         for usage_type in usage_type_attempts:
             response = pricing_client.get_products( ServiceCode='AWSELB', Filters=[ {'Type': 'TERM_MATCH', 'Field': 'productFamily', 'Value': product_family}, {'Type': 'TERM_MATCH', 'Field': 'location', 'Value': location}, {'Type': 'TERM_MATCH', 'Field': 'usagetype', 'Value': usage_type} ], MaxResults=1 )
             price_list = response.get('PriceList', [])
             if price_list:
                 price_item = json.loads(price_list[0]); terms = price_item.get('terms', {}).get('OnDemand', {})
                 if terms: term_key = list(terms.keys())[0]; price_dimensions = terms[term_key].get('priceDimensions', {}); price_key = list(price_dimensions.keys())[0]; price_str = price_dimensions[price_key].get('pricePerUnit', {}).get('USD')
                 if price_str: price_value = float(price_str); break
             if price_value is not None: break
         if price_value is None: logger.warning(f"Could not parse ELB price for {lb_type} in {region}")
         return price_value
     except (ClientError, KeyError, IndexError, ValueError, TypeError, json.JSONDecodeError) as e:
         logger.error(f"Error fetching/parsing pricing for {lb_type} Load Balancer in {region}: {e}")
         return None

# --- Service Specific Optimization Functions ---

def optimize_ec2(ec2_client, cloudwatch_client, compute_optimizer_client, region):
    """Optimize EC2: Terminate old stopped, report old gen & Compute Optimizer findings."""
    logger.info(f"--- Starting EC2 Optimization in {region} ---")
    now_utc = datetime.now(timezone.utc)
    results = { "savings": 0.0, "errors": [],
                "terminated_action": {"count": 0, "details": []},
                "older_gen_report": {"count": 0, "details": []},
                "compute_optimizer_report": {"count": 0, "details": []} }
    instances_to_terminate_ids = []; terminated_instance_ids = []

    if ENABLE_EC2_TERMINATION:
        try:
            stopped_cutoff_time = now_utc - timedelta(minutes=EC2_STOPPED_DAYS_THRESHOLD) # MINS FOR TEST
            logger.info(f"[{region}] Checking instances stopped before {stopped_cutoff_time.isoformat()}...")
            paginator = ec2_client.get_paginator("describe_instances")
            instances_to_terminate_candidates = []
            for page in paginator.paginate(Filters=[{"Name": "instance-state-name", "Values": ["stopped"]}]):
                for res in page["Reservations"]:
                    for inst in res["Instances"]:
                        if is_excluded(inst.get("Tags", [])): continue
                        stop_time = inst.get("UsageOperationUpdateTime", inst["LaunchTime"])
                        if 'User initiated' in inst.get('StateTransitionReason',''):
                            try: stop_time = datetime.strptime(inst['StateTransitionReason'].split('(')[-1].split(' GMT)')[0],'%Y-%m-%d %H:%M:%S').replace(tzinfo=timezone.utc)
                            except: pass
                        if stop_time < stopped_cutoff_time: instances_to_terminate_candidates.append({"id": inst["InstanceId"], "type": inst["InstanceType"], "stopped_time": stop_time})

            for info in instances_to_terminate_candidates:
                 inst_id, inst_type, stop_time_dt = info['id'], info['type'], info['stopped_time']
                 price = get_ec2_instance_price(inst_type, region); savings = (price * 24 * 30.44) if price else 0.0
                 if savings > 0: results['savings'] += savings
                 detail = f"{inst_id} ({inst_type}) - Stopped ~{stop_time_dt.strftime('%Y-%m-%d')} - Est ${savings:.2f}/mo"
                 results['terminated_action']['details'].append(detail); instances_to_terminate_ids.append(inst_id)

            results['terminated_action']['count'] = len(instances_to_terminate_ids)
            if instances_to_terminate_ids and not DRY_RUN:
                try: logger.info(f"Terminating {len(instances_to_terminate_ids)} instances..."); ec2_client.terminate_instances(InstanceIds=instances_to_terminate_ids); terminated_instance_ids.extend(instances_to_terminate_ids)
                except ClientError as e: results['errors'].append(f"EC2 Term Err:{e}")
        except ClientError as e: results['errors'].append(f"EC2 Desc Err:{e}")

    if ENABLE_EC2_OPTIMIZATION_REPORTING:
        try:
            paginator = ec2_client.get_paginator("describe_instances"); target_ids = set(instances_to_terminate_ids)
            older_gen_types = ['t2','m1','m2','m3','m4','c1','c3','c4','r3','r4','i2','d2','g2','f1','x1','p2','h1']; co_arns = []
            logger.info(f"[{region}] Checking instances for optimization reports...")
            for page in paginator.paginate(Filters=[{"Name": "instance-state-name", "Values": ["running", "stopped"]}]):
                for res in page["Reservations"]:
                    for inst in res["Instances"]:
                        inst_id, inst_type, tags = inst["InstanceId"], inst["InstanceType"], inst.get("Tags", [])
                        if inst_id in target_ids or is_excluded(tags): continue
                        if inst_type.split('.')[0] in older_gen_types: results['older_gen_report']['details'].append(f"{inst_id}({inst_type})")
                        if inst.get('State', {}).get('Name') in ['running', 'stopped']: co_arns.append(inst['InstanceArn'])
            results['older_gen_report']['count'] = len(results['older_gen_report']['details'])

            if co_arns:
                logger.info(f"[{region}] Getting Compute Optimizer recommendations for {len(co_arns)} instances...")
                try:
                    recs = []; co_paginator = compute_optimizer_client.get_paginator('get_ec2_instance_recommendations')
                    co_resp = compute_optimizer_client.get_ec2_instance_recommendations(instanceArns=co_arns[:100]) # Batch if needed
                    recs.extend(co_resp.get('instanceRecommendations', []))
                    # Add pagination logic if needed: while co_resp.get('nextToken'): ...

                    for rec in recs:
                        finding = rec.get('finding'); inst_arn = rec.get('instanceArn'); inst_id = inst_arn.split('/')[-1] if inst_arn else '?'
                        curr_type = rec.get('currentInstanceType', '?')
                        if finding in ['OVER_PROVISIONED', 'UNDER_PROVISIONED', 'OPTIMIZED', 'NOT_OPTIMIZED']:
                            reason = rec.get('findingReasonCodes', ['N/A'])[0] if rec.get('findingReasonCodes') else 'N/A'
                            opts = rec.get('recommendationOptions', []); opts_str = ", ".join([o.get('instanceType','?') for o in opts[:2]])
                            sv = opts[0].get('estimatedMonthlySavings',{}).get('value',0.0) if opts and finding=='OVER_PROVISIONED' else 0.0
                            detail = f"{inst_id}({curr_type}) - {finding}({reason}), Recs:[{opts_str}...], Est ${sv:.2f}/mo"
                            results['compute_optimizer_report']['details'].append(detail)
                    results['compute_optimizer_report']['count'] = len(results['compute_optimizer_report']['details'])
                except ClientError as e: results['errors'].append(f"CO Err:{e}")
                except Exception as e: results['errors'].append(f"CO Proc Err:{e}")
        except ClientError as e: results['errors'].append(f"EC2 Opt Rept Err:{e}")

    logger.info(f"--- Finished EC2 Optimization in {region} ---")
    return results, results['savings']


def optimize_ebs(ec2_client, cloudwatch_client, region):
    """Optimize EBS: Delete available, convert gp2->gp3, report idle, delete old snapshots."""
    logger.info(f"--- Starting EBS Optimization in {region} ---")
    now_utc = datetime.now(timezone.utc)
    # Initialize structured results
    results = {
        "savings": 0.0,
        "errors": [],
        "deleted_vol_action": {"count": 0, "details": []},
        "converted_vol_action": {"count": 0, "details": []},
        "deleted_snap_action": {"count": 0, "details": []},
        "idle_vol_report": {"count": 0, "details": []} # For idle volume reporting
    }
    # Internal tracking for DRY_RUN vs actual actions
    vol_would_del_ids, vol_would_conv_ids, snap_would_del_ids = [], [], []
    vol_del_ids, vol_conv_ids, snap_del_ids = [], [], []

    # Get prices upfront
    gp2_p, gp3_p, snap_p = get_ebs_price('gp2', region), get_ebs_price('gp3', region), get_ebs_snapshot_price(region)

    # --- 1. Delete available volumes ---
    if ENABLE_EBS_AVAILABLE_VOLUME_DELETION:
        try:
            logger.info(f"[{region}] Checking for 'available' volumes...")
            paginator = ec2_client.get_paginator("describe_volumes"); avail_vols = []
            for page in paginator.paginate(Filters=[{"Name": "status", "Values": ["available"]}]):
                for vol in page['Volumes']:
                    if not is_excluded(vol.get("Tags", [])):
                        avail_vols.append({'id':vol['VolumeId'],'size':vol['Size'],'type':vol['VolumeType']})

            results['deleted_vol_action']['count'] = len(avail_vols) # Count potential deletes
            logger.info(f"[{region}] Found {len(avail_vols)} candidate available volumes.")
            for v in avail_vols:
                vp=get_ebs_price(v['type'], region); vs=(v['size']*vp) if vp is not None else 0.0
                if vs > 0: results['savings'] += vs # Add potential savings
                detail=f"{v['id']} ({v['type']}, {v['size']}GB) - Est Savings: ${vs:.2f}/mo"
                results['deleted_vol_action']['details'].append(detail); vol_would_del_ids.append(v['id'])

                # Corrected block for actual deletion
                if not DRY_RUN:
                    try:
                        logger.info(f"[{region}] Deleting available volume {v['id']}...")
                        ec2_client.delete_volume(VolumeId=v['id'])
                        vol_del_ids.append(v['id']) # Track successful deletion
                        logger.info(f"[{region}] Successfully deleted volume {v['id']}.")
                    except ClientError as e:
                        logger.error(f"[{region}] Error deleting volume {v['id']}: {e}")
                        results['errors'].append(f"VolDelErr({v['id']}):{e}")
                        results['savings']-=vs # Subtract savings on failure
        except ClientError as e: results['errors'].append(f"DescAvailVolErr:{e}")

    # --- 2. Convert GP2 to GP3 ---
    processed_for_conversion = set(vol_would_del_ids) # Check against potential deletes
    if ENABLE_EBS_GP2_TO_GP3_CONVERSION:
        try:
            logger.info(f"[{region}] Checking for gp2 volumes to convert...")
            paginator=ec2_client.get_paginator("describe_volumes"); vols_to_conv=[]
            for page in paginator.paginate(Filters=[{'Name':'volume-type','Values':['gp2']}]):
                for vol in page['Volumes']:
                    vol_id=vol['VolumeId']; tags=vol.get("Tags",[])
                    if vol_id in processed_for_conversion or is_excluded(tags): continue
                    is_root = any(a.get('Device') in ['/dev/sda1','/dev/xvda'] for a in vol.get('Attachments',[]))
                    if is_root and not ENABLE_EBS_GP2_TO_GP3_CONVERSION_FOR_ROOT: continue
                    vols_to_conv.append({'id':vol_id, 'size':vol['Size']})

            results['converted_vol_action']['count'] = len(vols_to_conv) # Count potential conversions
            logger.info(f"[{region}] Found {len(vols_to_conv)} candidate gp2 volumes.")
            if gp2_p is not None and gp3_p is not None and gp2_p > gp3_p:
                sav_gb=gp2_p - gp3_p
                logger.info(f"[{region}] Potential savings per GB for gp2->gp3: ${sav_gb:.4f}")
                for v in vols_to_conv:
                    vs=v['size']*sav_gb; results['savings']+=vs # Add potential savings
                    detail=f"{v['id']} ({v['size']}GB) - Est Savings: ${vs:.2f}/mo"
                    results['converted_vol_action']['details'].append(detail); vol_would_conv_ids.append(v['id'])

                    # Corrected block for actual modification
                    if not DRY_RUN:
                        try:
                            logger.info(f"[{region}] Converting gp2 volume {v['id']} to gp3...")
                            ec2_client.modify_volume(VolumeId=v['id'],VolumeType='gp3')
                            vol_conv_ids.append(v['id']) # Track successful action
                            logger.info(f"[{region}] Successfully initiated conversion for {v['id']}.")
                        except ClientError as e:
                            logger.error(f"[{region}] Error modifying volume {v['id']}: {e}")
                            results['errors'].append(f"VolModErr({v['id']}):{e}")
                            results['savings']-=vs # Subtract savings on failure
            else: logger.warning(f"[{region}] Cannot calculate gp2->gp3 savings (pricing missing or no benefit).")
        except ClientError as e: results['errors'].append(f"DescGp2VolErr:{e}")

    # --- 3. Report Idle Volumes ---
    processed_for_idle = processed_for_conversion.union(set(vol_would_conv_ids)) # Skip deleted or converted
    if ENABLE_EBS_IDLE_VOLUME_REPORTING:
         try:
            logger.info(f"[{region}] Checking for idle EBS volumes (IdleTime > {EBS_IDLE_TIME_THRESHOLD_PERCENT}% over {EBS_IDLE_CHECK_DAYS} days)...")
            # !!! WARNING: Using minutes for testing. Change to days for production. !!!
            check_start_time = now_utc - timedelta(minutes=EBS_IDLE_CHECK_DAYS) # Mins for testing
            # check_start_time = now_utc - timedelta(days=EBS_IDLE_CHECK_DAYS) # Days for production
            paginator = ec2_client.get_paginator("describe_volumes")
            page_iterator = paginator.paginate(Filters=[{"Name": "status", "Values": ["in-use"]}])
            idle_vols_found = []

            for page in page_iterator:
                 for volume in page['Volumes']:
                     vol_id = volume['VolumeId']; tags = volume.get("Tags", [])
                     if vol_id in processed_for_idle or is_excluded(tags): continue
                     try:
                         metrics = cloudwatch_client.get_metric_statistics( Namespace='AWS/EBS', MetricName='VolumeIdleTime', Dimensions=[{'Name':'VolumeId','Value':vol_id}], StartTime=check_start_time, EndTime=now_utc, Period=86400, Statistics=['Average'], Unit='Seconds' )
                         avgs = [dp['Average'] for dp in metrics['Datapoints']]
                         if avgs: p_idle=(mean(avgs)/86400)*100 if mean(avgs) is not None else 0
                         else: p_idle = -1 # Indicate no metrics found
                         if p_idle > EBS_IDLE_TIME_THRESHOLD_PERCENT: idle_vols_found.append(f"{vol_id} ({p_idle:.1f}% idle)")
                         elif p_idle < 0: logger.debug(f"No IdleTime metrics for {vol_id}")
                     except (ClientError,KeyError,ValueError,TypeError) as e: results['errors'].append(f"EBSIdleMetricErr({vol_id}):{e}")

            results['idle_vol_report']['count'] = len(idle_vols_found)
            results['idle_vol_report']['details'] = idle_vols_found
            if idle_vols_found: logger.info(f"[{region}] Found {len(idle_vols_found)} potentially idle volumes.")
            else: logger.info(f"[{region}] No potentially idle volumes found.")
         except ClientError as e: results['errors'].append(f"EBSDescInUseErr:{e}")

    # --- 4. Delete old snapshots ---
    if ENABLE_EBS_SNAPSHOT_DELETION:
        try:
            # !!! WARNING: Using minutes for testing. Change to days for production. !!!
            cutoff = now_utc - timedelta(minutes=EBS_SNAPSHOT_RETENTION_DAYS) # Mins for testing
            logger.info(f"[{region}] Checking snapshots older than {cutoff.isoformat()}...")
            paginator = ec2_client.get_paginator("describe_snapshots"); snaps_to_del=[]
            for page in paginator.paginate(OwnerIds=["self"]):
                for snap in page['Snapshots']:
                    desc = snap.get('Description','').lower()
                    if 'createimage' in desc or 'aws backup' in desc or 'dlm lifecycle' in desc: continue
                    snap_id = snap['SnapshotId']
                    if is_excluded(snap.get("Tags",[])): continue
                    if snap['StartTime'] < cutoff: snaps_to_del.append({'id':snap_id,'size':snap['VolumeSize'],'time':snap['StartTime']})

            results['deleted_snap_action']['count'] = len(snaps_to_del) # Count potential deletes
            logger.info(f"[{region}] Found {len(snaps_to_del)} candidate old snapshots.")
            if snap_p is not None:
                for s in snaps_to_del:
                    ss = s['size']*snap_p; results['savings']+=ss # Add potential savings
                    detail=f"{s['id']}(Sz:{s['size']}GB,Created:{s['time']:%Y-%m-%d})-Est ${ss:.2f}/mo"
                    results['deleted_snap_action']['details'].append(detail); snap_would_del_ids.append(s['id'])
                    if not DRY_RUN:
                        try:
                            logger.info(f"Deleting snap {s['id']}. Est ${ss:.2f}")
                            ec2_client.delete_snapshot(SnapshotId=s['id']); snap_del_ids.append(s['id']) # Track actual deletes
                        except ClientError as e:
                            results['errors'].append(f"SnapDelErr({s['id']}):{e}"); results['savings']-=ss # Subtract savings on failure
            else: logger.warning(f"[{region}] Cannot calculate snapshot savings (price unavailable).")
        except ClientError as e: results['errors'].append(f"DescSnapErr:{e}")

    logger.info(f"--- Finished EBS Optimization in {region} ---")

    # Finalize counts based on actual actions if not DRY_RUN
    if not DRY_RUN:
        results['deleted_vol_action']['count'] = len(vol_del_ids)
        results['converted_vol_action']['count'] = len(vol_conv_ids)
        results['deleted_snap_action']['count'] = len(snap_del_ids)
        # Idle report count remains based on identification

    return results, results['savings']

def optimize_load_balancers(elbv2_client, cloudwatch_client, region):
    logger.info(f"--- Starting Load Balancer Optimization in {region} ---")
    results = {"savings": 0.0, "errors": [], "deleted_action": {"count": 0, "details": []}}
    lbs_to_del_info = []; deleted_lb_names = [] # Internal tracking
    if not ENABLE_ELB_DELETION: return {"summary_lines":["ELB deletion disabled."]}, 0.0

    now_utc = datetime.now(timezone.utc)
    cutoff = now_utc - timedelta(minutes=ELB_IDLE_DAYS_THRESHOLD) # MINS FOR TEST
    logger.info(f"[{region}] Checking LBs idle since {cutoff.isoformat()}...")

    try:
        paginator = elbv2_client.get_paginator('describe_load_balancers')
        for page in paginator.paginate():
            for lb in page['LoadBalancers']:
                arn, name, type, state = lb['LoadBalancerArn'], lb['LoadBalancerName'], lb['Type'], lb.get('State',{}).get('Code')
                if state != 'active': continue
                try:
                    tags = elbv2_client.describe_tags(ResourceArns=[arn])['TagDescriptions'][0].get('Tags',[])
                    if is_excluded(tags) or type == 'gateway': continue
                    metric = 'RequestCount' if type == 'application' else 'ActiveFlowCount'
                    ns = 'AWS/ApplicationELB' if type == 'application' else 'AWS/NetworkELB'
                    period = max(60, 3600 if (ELB_IDLE_DAYS_THRESHOLD*60)>=3600 else 300)
                    metrics = cloudwatch_client.get_metric_statistics( Namespace=ns, MetricName=metric, Dimensions=[{'Name':'LoadBalancer','Value':'/'.join(arn.split(':')[-1].split('/')[-3:])}], StartTime=cutoff, EndTime=now_utc, Period=period, Statistics=['Sum'], Unit='Count')
                    count = sum(dp['Sum'] for dp in metrics['Datapoints'])
                    tgs = elbv2_client.describe_target_groups(LoadBalancerArn=arn)['TargetGroups']
                    unhealthy = not tgs or all( not thd or all(t['TargetHealth']['State'] not in ['healthy','initial','draining'] for t in thd) for tg in tgs if (thd := elbv2_client.describe_target_health(TargetGroupArn=tg['TargetGroupArn'])['TargetHealthDescriptions']) is not None)
                    if count < 1 and unhealthy:
                        logger.info(f"[{region}] Found idle {type} LB {name}.")
                        price = get_elb_price(type, region); savings = (price*24*30.44) if price else 0.0
                        lbs_to_del_info.append({'Arn':arn,'Name':name,'Type':type, 'Savings': savings})
                        if savings > 0: results['savings'] += savings
                except ClientError as e: results['errors'].append(f"LB Proc Err ({name}):{e}")
                except Exception as e: results['errors'].append(f"LB Unexp Err ({name}):{e}"); logger.error("LB Unexp Err",exc_info=True)
    except ClientError as e: results['errors'].append(f"Desc LBs Err:{e}")

    results['deleted_action']['count'] = len(lbs_to_del_info)
    if lbs_to_del_info:
        logger.info(f"[{region}] Processing {len(lbs_to_del_info)} LBs for deletion.")
        for lb in lbs_to_del_info:
            arn, name, type, sv = lb['Arn'], lb['Name'], lb['Type'], lb['Savings']
            detail = f"{name} ({type}) - Est Savings: ${sv:.2f}/mo"
            results['deleted_action']['details'].append(detail)
            if not DRY_RUN:
                try: logger.info(f"Deleting {type} LB {name}."); elbv2_client.delete_load_balancer(LoadBalancerArn=arn); deleted_lb_names.append(name)
                except ClientError as e: results['errors'].append(f"LB Del Err ({name}):{e}"); results['savings'] -= sv
        # Update count for non-dry run summary
        if not DRY_RUN: results['deleted_action']['count'] = len(deleted_lb_names)

    logger.info(f"--- Finished Load Balancer Optimization in {region} ---")
    return results, results['savings']

def optimize_elastic_ips(ec2_client, region):
    logger.info(f"--- Starting Elastic IP Optimization in {region} ---")
    results = {"savings": 0.0, "errors": [], "released_action": {"count": 0, "details": []}, "skipped": []}
    if not ENABLE_EIP_RELEASE: return {"summary_lines":["EIP release disabled."]}, 0.0

    to_release_ids = []; released_ids = []
    monthly_cost = UNATTACHED_EIP_PRICE_HOURLY * 24 * 30.44

    try:
        for addr in ec2_client.describe_addresses().get("Addresses",[]):
            alloc_id, ip, tags = addr.get("AllocationId"), addr.get("PublicIp"), addr.get("Tags",[])
            if "AssociationId" in addr: continue
            if is_excluded(tags): results['skipped'].append(ip); continue
            logger.info(f"[{region}] Found unattached EIP: {ip} ({alloc_id}).")
            to_release_ids.append(alloc_id); results['savings'] += monthly_cost
            results['released_action']['details'].append(f"{ip} ({alloc_id}) - Est Savings: ${monthly_cost:.2f}/mo")

        results['released_action']['count'] = len(to_release_ids)
        if to_release_ids and not DRY_RUN:
            logger.info(f"[{region}] Processing {len(to_release_ids)} EIPs.")
            for alloc_id in to_release_ids:
                try: logger.info(f"Releasing EIP {alloc_id}."); ec2_client.release_address(AllocationId=alloc_id); released_ids.append(alloc_id)
                except ClientError as e: results['errors'].append(f"EIP Rel Err ({alloc_id}):{e}"); results['savings'] -= monthly_cost
            results['released_action']['count'] = len(released_ids) # Update count based on actual success
        elif not to_release_ids: logger.info(f"[{region}] No unattached EIPs found.")
    except ClientError as e: results['errors'].append(f"DescAddr Err:{e}")

    logger.info(f"--- Finished Elastic IP Optimization in {region} ---")
    return results, results['savings']


def optimize_cloudwatch_logs(logs_client, region):
    """Set retention periods for CloudWatch Log Groups, reporting $0 savings."""
    logger.info(f"--- Starting CloudWatch Log Group Optimization in {region} ---")
    # Initialize structured results
    results = {
        "savings": 0.0, # Explicitly $0 for CW Logs
        "errors": [],
        "modified_action": {"count": 0, "details": []}, # Details of groups modified
        "skipped": [] # List of skipped group names
    }
    if not ENABLE_CW_LOG_GROUP_RETENTION_MANAGEMENT:
        logger.info(f"[{region}] CW Log Group retention management disabled.")
        # Add a line to results summary if needed
        results['summary_lines'] = ["CW Log Group retention disabled."]
        return results, 0.0

    # Internal tracking
    log_groups_would_modify_names = []
    log_groups_modified_count = 0

    try:
        paginator = logs_client.get_paginator('describe_log_groups')
        page_iterator = paginator.paginate()

        for page in page_iterator:
            for log_group in page.get('logGroups', []):
                lg_name = log_group['logGroupName']
                current_retention = log_group.get('retentionInDays')
                tags = {} # Initialize empty

                # Fetch tags safely
                try:
                    tags_response = logs_client.list_tags_log_group(logGroupName=lg_name)
                    tags = tags_response.get('tags', {}) # Returns dict
                except ClientError as e:
                    if e.response['Error']['Code'] == 'ResourceNotFoundException':
                        logger.warning(f"[{region}] LG {lg_name} not found listing tags. Skipping.")
                        continue # Skip this log group
                    else:
                        logger.warning(f"[{region}] Could not list tags for LG {lg_name}: {e}. Proceeding without tag checks.")
                        results['errors'].append(f"TagListErr({lg_name}):{e}")
                        # Continue processing without tags

                # Check Exclusion Tag
                if is_excluded(tags): # is_excluded handles dict or list
                    logger.info(f"[{region}] Skipping excluded Log Group {lg_name}")
                    results['skipped'].append(lg_name)
                    continue

                # Determine target retention
                env_tag_value = tags.get(ENVIRONMENT_TAG_KEY, '').lower()
                target_retention = CW_LOG_GROUP_RETENTION_DEFAULT_DAYS
                if env_tag_value in ENV_VALUES_PROD or env_tag_value in ENV_VALUES_UAT:
                    target_retention = CW_LOG_GROUP_RETENTION_PROD_UAT_DAYS
                elif env_tag_value in ENV_VALUES_DEV:
                    target_retention = CW_LOG_GROUP_RETENTION_DEV_DAYS

                # Apply retention if needed
                needs_update = False
                original_retention_str = "'Never expire'" if current_retention is None else f"{current_retention} days"
                if current_retention is None or current_retention > target_retention:
                    needs_update = True
                    # Log intention regardless of DRY_RUN
                    logger.info(f"[{region}] LG {lg_name} retention {original_retention_str} needs update to {target_retention} days.")

                if needs_update:
                    detail = f"{lg_name}: {original_retention_str} -> {target_retention} days"
                    results['modified_action']['details'].append(detail)
                    log_groups_would_modify_names.append(lg_name) # Track potential action

                    if not DRY_RUN:
                        try:
                            logger.info(f"[{region}] Setting retention for Log Group {lg_name} to {target_retention} days.")
                            logs_client.put_retention_policy(
                                logGroupName=lg_name,
                                retentionInDays=target_retention
                            )
                            log_groups_modified_count += 1 # Track successful action
                            logger.info(f"[{region}] Successfully set retention for Log Group {lg_name}.")
                        except ClientError as e:
                            logger.error(f"[{region}] Error setting retention for Log Group {lg_name}: {e}")
                            results['errors'].append(f"SetRetErr({lg_name}):{e}")

        # Finalize counts based on DRY_RUN status
        results['modified_action']['count'] = len(log_groups_would_modify_names) if DRY_RUN else log_groups_modified_count

        if results['modified_action']['count'] > 0:
            action = "Would modify" if DRY_RUN else "Modified"
            logger.info(f"[{region}] {action} retention policy for {results['modified_action']['count']} Log Group(s).")
        else:
            logger.info(f"[{region}] No Log Groups required retention policy updates based on criteria.")

    except ClientError as e:
        logger.error(f"[{region}] Error describing CloudWatch Log Groups: {e}")
        results['errors'].append(f"DescLGErr: {e}")

    logger.info(f"--- Finished CloudWatch Log Group Optimization in {region} ---")

    # Build summary lines for return (optional, as handler uses dict now)
    summary_lines = []
    count = results['modified_action']['count']
    if count > 0: summary_lines.append(f"{'Would modify' if DRY_RUN else 'Modified'} retention for {count} LG(s).")
    else: summary_lines.append("No LGs needed retention updates.")
    if results['skipped']: summary_lines.append(f"Skipped {len(results['skipped'])} excluded LG(s).")
    if results['errors']: summary_lines.append(f"Errors: {len(results['errors'])}")
    summary_lines.append("$0.00 USD/month estimated savings by CW Logs")
    results['summary_lines'] = summary_lines # Store summary for potential direct use

    return results, 0.0 # Always return $0 savings
def report_cloudwatch_alarms(cloudwatch_client, region):
    """Report on CloudWatch alarms potentially suitable for removal."""
    logger.info(f"--- Starting CloudWatch Alarm Reporting in {region} ---")
    # Initialize structured results
    results = {
        "errors": [],
        "insufficient_data_report": {"count": 0, "details": []}, # List alarms found
        "skipped": [] # List of skipped alarm names (optional)
    }
    if not ENABLE_CW_INSUFFICIENT_DATA_ALARM_REPORTING:
        logger.info(f"[{region}] CW Alarm reporting disabled.")
        results["summary_lines"] = ["CW Alarm reporting disabled."] # Add summary if needed
        return results # No savings

    now_utc = datetime.now(timezone.utc)
    # !!! WARNING: Using minutes for testing. Change to days for production. !!!
    cutoff = now_utc - timedelta(minutes=CW_ALARM_INSUFFICIENT_DATA_DAYS_THRESHOLD) # Mins for testing
    # cutoff = now_utc - timedelta(days=CW_ALARM_INSUFFICIENT_DATA_DAYS_THRESHOLD) # Days for production
    logger.info(f"[{region}] Checking alarms in INSUFFICIENT_DATA since {cutoff.isoformat()}...")

    alarms_to_report_details = [] # Use temporary list for details

    try:
        paginator = cloudwatch_client.get_paginator('describe_alarms')
        for page in paginator.paginate():
            # Combine Metric and Composite alarms if needed
            for alarm in page.get('MetricAlarms', []) + page.get('CompositeAlarms', []):
                alarm_name = alarm['AlarmName']
                alarm_arn = alarm['AlarmArn']
                state_value = alarm.get('StateValue')
                state_updated_timestamp = alarm.get('StateUpdatedTimestamp')

                # Filter for relevant state and timestamp
                if state_value != 'INSUFFICIENT_DATA' or not state_updated_timestamp:
                    continue

                tags = [] # Initialize empty list for tags
                # --- CORRECTED BLOCK ---
                try:
                    tag_response = cloudwatch_client.list_tags_for_resource(ResourceARN=alarm_arn)
                    tags = tag_response.get('Tags', []) # Assign tags if successful
                except ClientError as e:
                    # Log warning but continue without tags for exclusion check
                    logger.warning(f"[{region}] Could not list tags for alarm {alarm_name}: {e}.")
                    results['errors'].append(f"Alarm Tag Err ({alarm_name}): {e}") # Log error in results
                    pass # Proceed without tags
                # --- END CORRECTED BLOCK ---

                if is_excluded(tags):
                    logger.info(f"[{region}] Skipping excluded Alarm {alarm_name}")
                    results['skipped'].append(alarm_name) # Add to skipped list
                    continue

                # Check timestamp against cutoff
                if state_updated_timestamp < cutoff:
                    detail = f"{alarm_name} (since {state_updated_timestamp:%Y-%m-%d %H:%M})"
                    logger.info(f"[{region}] Found alarm meeting criteria: {detail}")
                    alarms_to_report_details.append(detail)

        # Finalize results dictionary
        results['insufficient_data_report']['count'] = len(alarms_to_report_details)
        results['insufficient_data_report']['details'] = alarms_to_report_details

        # Log summary warning if any found
        if results['insufficient_data_report']['count'] > 0:
            logger.warning(f"[{region}] {results['insufficient_data_report']['count']} Alarms in INSUFFICIENT_DATA > {CW_ALARM_INSUFFICIENT_DATA_DAYS_THRESHOLD} minutes found:")
            for detail in alarms_to_report_details[:5]: logger.warning(f"  - {detail}") # Log first few
            if len(alarms_to_report_details) > 5: logger.warning("  - ...")
            logger.warning(f"[{region}] Review removal from IaC source recommended.")
        else:
            logger.info(f"[{region}] No long-standing INSUFFICIENT_DATA alarms found.")

    except ClientError as e:
        logger.error(f"[{region}] Error describing CloudWatch Alarms: {e}")
        results['errors'].append(f"DescAlarmsErr:{e}")

    logger.info(f"--- Finished CloudWatch Alarm Reporting in {region} ---")

    # Build optional summary lines
    summary_lines = []
    count = results['insufficient_data_report']['count']
    if count > 0: summary_lines.append(f"Found {count} long-standing INSUFFICIENT_DATA alarm(s).")
    else: summary_lines.append("No long-standing INSUFFICIENT_DATA alarms.")
    if results['skipped']: summary_lines.append(f"Skipped {len(results['skipped'])} excluded alarm(s).")
    if results['errors']: summary_lines.append(f"Errors: {len(results['errors'])}")
    results['summary_lines'] = summary_lines # Store for potential direct use

    return results # Return structured results (no savings)

# --- Add this near the top with other imports if not already present ---
from statistics import mean

# --- Replace the existing optimize_rds function with this ---

def optimize_rds(rds_client, cloudwatch_client, region):
    """Optimize RDS: retention, snapshots, report low CPU."""
    logger.info(f"--- Starting RDS Optimization in {region} ---")
    now_utc = datetime.now(timezone.utc)
    # Initialize structured results
    results = {
        "savings": 0.0,
        "errors": [],
        "modified_inst_ret_action": {"count": 0, "details": []},
        "modified_clus_ret_action": {"count": 0, "details": []},
        "deleted_inst_snap_action": {"count": 0, "details": []},
        "deleted_clus_snap_action": {"count": 0, "details": []},
        "low_cpu_report": {"count": 0, "details": []}
    }
    # Internal tracking
    processed_clusters = set()
    clus_would_mod, inst_would_mod = set(), []
    snap_would_del, clus_snap_would_del = [], []
    snap_del, clus_snap_del = [], []
    inst_mod_cnt, clus_mod_cnt = 0, 0

    # --- 1. Adjust Retention & Report Low CPU ---
    if ENABLE_RDS_BACKUP_RETENTION_ADJUSTMENT or ENABLE_RDS_LOW_CPU_REPORTING:
        logger.info(f"[{region}] Checking RDS instances/clusters...")
        try:
            paginator = rds_client.get_paginator('describe_db_instances')
            # !!! WARNING: Using minutes for testing. Change to days for production. !!!
            check_start_time = now_utc - timedelta(minutes=RDS_RIGHTSIZE_CHECK_DAYS) # Mins for testing
            # check_start_time = now_utc - timedelta(days=RDS_RIGHTSIZE_CHECK_DAYS) # Days for production

            for page in paginator.paginate():
                for inst in page.get('DBInstances', []):
                    inst_id, inst_arn, clus_id = inst['DBInstanceIdentifier'], inst['DBInstanceArn'], inst.get('DBClusterIdentifier')

                    # Get instance tags (used for exclusion checks below)
                    tags = []
                    try:
                        tags = rds_client.list_tags_for_resource(ResourceName=inst_arn).get('TagList', [])
                    except ClientError as e:
                        logger.warning(f"[{region}] Could not get tags for instance {inst_id}: {e}. Proceeding without tag check for instance itself.")

                    if is_excluded(tags):
                        logger.info(f"[{region}] Skipping excluded instance {inst_id} based on its own tags.")
                        continue

                    # -- Cluster Processing --
                    if clus_id:
                        if clus_id in processed_clusters: continue
                        processed_clusters.add(clus_id)
                        try:
                            clus = rds_client.describe_db_clusters(DBClusterIdentifier=clus_id)['DBClusters'][0]
                            clus_tags = [] # Initialize cluster tags
                            try: # Get cluster tags separately
                                clus_tags = rds_client.list_tags_for_resource(ResourceName=clus['DBClusterArn']).get('TagList', [])
                            except ClientError as e:
                                logger.warning(f"[{region}] Could not get tags for cluster {clus_id}: {e}.")

                            if is_excluded(clus_tags): # Check cluster tags for exclusion
                                logger.info(f"[{region}] Skipping excluded cluster {clus_id} based on its tags.")
                                continue

                            # Retention Check
                            if ENABLE_RDS_BACKUP_RETENTION_ADJUSTMENT:
                                cur_ret = clus['BackupRetentionPeriod']
                                if cur_ret > RDS_MAX_BACKUP_RETENTION_DAYS:
                                    detail = f"Cluster {clus_id}: {cur_ret}d -> {RDS_MAX_BACKUP_RETENTION_DAYS}d"
                                    results['modified_clus_ret_action']['details'].append(detail)
                                    clus_would_mod.add(clus_id) # Track potential action
                                    if not DRY_RUN:
                                        try:
                                            logger.info(f"[{region}] Modifying cluster {clus_id} retention...")
                                            rds_client.modify_db_cluster(DBClusterIdentifier=clus_id, BackupRetentionPeriod=RDS_MAX_BACKUP_RETENTION_DAYS)
                                            clus_mod_cnt += 1 # Track actual action
                                        except ClientError as e:
                                            results['errors'].append(f"ClusModErr({clus_id}):{e}")
                        except (ClientError, IndexError) as e:
                            results['errors'].append(f"ClusFetchErr({clus_id}):{e}")

                    # -- Standalone Instance Processing --
                    else:
                        # Retention Check
                        ret = inst.get('BackupRetentionPeriod')
                        if ENABLE_RDS_BACKUP_RETENTION_ADJUSTMENT and ret is not None and ret > RDS_MAX_BACKUP_RETENTION_DAYS:
                            # Exclusion already checked using instance tags
                            detail = f"Instance {inst_id}: {ret}d -> {RDS_MAX_BACKUP_RETENTION_DAYS}d"
                            results['modified_inst_ret_action']['details'].append(detail)
                            inst_would_mod.append(inst_id) # Track potential action
                            if not DRY_RUN:
                                try:
                                    logger.info(f"[{region}] Modifying instance {inst_id} retention...")
                                    rds_client.modify_db_instance(DBInstanceIdentifier=inst_id, BackupRetentionPeriod=RDS_MAX_BACKUP_RETENTION_DAYS, ApplyImmediately=False)
                                    inst_mod_cnt += 1 # Track actual action
                                except ClientError as e:
                                    results['errors'].append(f"InstModErr({inst_id}):{e}")

                        # Low CPU Check
                        if ENABLE_RDS_LOW_CPU_REPORTING and inst.get('DBInstanceStatus') == 'available':
                            # Exclusion already checked using instance tags
                            try:
                                metrics = cloudwatch_client.get_metric_statistics(Namespace='AWS/RDS', MetricName='CPUUtilization', Dimensions=[{'Name': 'DBInstanceIdentifier', 'Value': inst_id}], StartTime=check_start_time, EndTime=now_utc, Period=86400, Statistics=['Average'], Unit='Percent')
                                avgs = [dp['Average'] for dp in metrics['Datapoints']]; avg_cpu = -1
                                if avgs: avg_cpu = mean(avgs)
                                if avg_cpu >= 0 and avg_cpu < RDS_LOW_CPU_THRESHOLD_PERCENT:
                                    results['low_cpu_report']['details'].append(f"{inst_id}({avg_cpu:.1f}% avg CPU)")
                            except (ClientError, KeyError, ValueError, TypeError) as e:
                                results['errors'].append(f"RDS CPU Err({inst_id}):{e}")
        except ClientError as e:
            results['errors'].append(f"DescInstErr:{e}")

    # --- 2 & 3. Snapshot Deletion ---
    if ENABLE_RDS_MANUAL_SNAPSHOT_DELETION:
        # !!! WARNING: Using minutes for testing. Change to days for production. !!!
        cutoff = now_utc - timedelta(minutes=RDS_MANUAL_SNAPSHOT_RETENTION_DAYS) # Mins for testing

        try: # Instance Snaps
            logger.info(f"[{region}] Checking inst snaps older than {cutoff.isoformat()}...")
            paginator = rds_client.get_paginator('describe_db_snapshots')
            snaps_to_proc = []
            for page in paginator.paginate(SnapshotType='manual', IncludeShared=False):
                for snap in page.get('DBSnapshots', []):
                    sid, arn, stime = snap['DBSnapshotIdentifier'], snap['DBSnapshotArn'], snap.get('SnapshotCreateTime')
                    tags = []
                    try: # Corrected Tag Block
                        tags = rds_client.list_tags_for_resource(ResourceName=arn).get('TagList', [])
                    except ClientError as e:
                        logger.warning(f"[{region}] Could not get tags for inst snap {sid}: {e}.")
                    # End Corrected Tag Block
                    if is_excluded(tags): continue
                    if snap.get('Status') == 'available' and stime and stime < cutoff:
                        snaps_to_proc.append({'id': sid, 'size': snap.get('AllocatedStorage', 0), 'time': stime})

            results['deleted_inst_snap_action']['count'] = len(snaps_to_proc) # Set potential count
            for s in snaps_to_proc:
                sv = s['size'] * RDS_SNAPSHOT_PRICE_GB_MONTH
                results['savings'] += sv # Add potential savings
                detail = f"{s['id']}(Sz:{s['size']}GB,Crtd:{s['time']:%Y-%m-%d})-Est ${sv:.2f}/mo"
                results['deleted_inst_snap_action']['details'].append(detail)
                snap_would_del.append(s['id']) # Track potential action

                # Corrected Deletion Block
                if not DRY_RUN:
                    try:
                        logger.info(f"[{region}] Deleting RDS instance snapshot {s['id']}...")
                        rds_client.delete_db_snapshot(DBSnapshotIdentifier=s['id'])
                        snap_del.append(s['id']) # Track actual deletion
                        logger.info(f"[{region}] Successfully deleted instance snapshot {s['id']}.")
                    except ClientError as e:
                        logger.error(f"[{region}] Error deleting instance snapshot {s['id']}: {e}")
                        results['errors'].append(f"ISnapDelErr({s['id']}):{e}")
                        results['savings'] -= sv # Subtract savings on failure
        except ClientError as e:
            results['errors'].append(f"DescISnapErr:{e}")

        try: # Cluster Snaps
            logger.info(f"[{region}] Checking clus snaps older than {cutoff.isoformat()}...")
            paginator = rds_client.get_paginator('describe_db_cluster_snapshots')
            snaps_to_proc = []
            for page in paginator.paginate(SnapshotType='manual', IncludeShared=False):
                 for snap in page.get('DBClusterSnapshots', []):
                    sid, arn, stime = snap['DBClusterSnapshotIdentifier'], snap['DBClusterSnapshotArn'], snap.get('SnapshotCreateTime')
                    tags = []
                    try: # Corrected Tag Block
                        tags = rds_client.list_tags_for_resource(ResourceName=arn).get('TagList', [])
                    except ClientError as e:
                        logger.warning(f"[{region}] Could not get tags for cluster snap {sid}: {e}.")
                    # End Corrected Tag Block
                    if is_excluded(tags): continue
                    if snap.get('Status') == 'available' and stime and stime < cutoff:
                        sz = snap.get('AllocatedStorage', 0)
                        sz = sz if isinstance(sz, (int, float)) else 0
                        snaps_to_proc.append({'id': sid, 'size': sz, 'time': stime})

            results['deleted_clus_snap_action']['count'] = len(snaps_to_proc) # Set potential count
            for s in snaps_to_proc:
                sv = s['size'] * RDS_SNAPSHOT_PRICE_GB_MONTH
                results['savings'] += sv # Add potential savings
                detail = f"{s['id']}(Sz:{s['size']}GB,Crtd:{s['time']:%Y-%m-%d})-Est ${sv:.2f}/mo"
                results['deleted_clus_snap_action']['details'].append(detail)
                clus_snap_would_del.append(s['id']) # Track potential action

                # Corrected Deletion Block
                if not DRY_RUN:
                    try:
                        logger.info(f"[{region}] Deleting RDS cluster snapshot {s['id']}...")
                        rds_client.delete_db_cluster_snapshot(DBClusterSnapshotIdentifier=s['id'])
                        clus_snap_del.append(s['id']) # Track actual deletion
                        logger.info(f"[{region}] Successfully deleted cluster snapshot {s['id']}.")
                    except ClientError as e:
                        logger.error(f"[{region}] Error deleting cluster snapshot {s['id']}: {e}")
                        results['errors'].append(f"CSnapDelErr({s['id']}):{e}")
                        results['savings'] -= sv # Subtract savings on failure
        except ClientError as e:
            results['errors'].append(f"DescCSnapErr:{e}")

    # Finalize counts based on DRY_RUN status
    if DRY_RUN:
         results['modified_inst_ret_action']['count'] = len(inst_would_mod)
         results['modified_clus_ret_action']['count'] = len(clus_would_mod)
         # Snapshot counts already set based on identified snaps
    else:
         results['modified_inst_ret_action']['count'] = inst_mod_cnt
         results['modified_clus_ret_action']['count'] = clus_mod_cnt
         results['deleted_inst_snap_action']['count'] = len(snap_del)
         results['deleted_clus_snap_action']['count'] = len(clus_snap_del)
    results['low_cpu_report']['count'] = len(results['low_cpu_report']['details'])

    logger.info(f"--- Finished RDS Optimization in {region} ---")
    return results, results['savings']


def optimize_s3(s3_client, region):
    logger.info(f"--- Starting S3 Optimization in {region} ---")
    results = {"savings": 0.0, "errors": [], "processed_buckets": 0, "deleted_action": {"count": 0, "details": []}}
    if not ENABLE_S3_OBJECT_DELETION:
        results['summary_lines'] = ["S3 object deletion disabled."]
        return results, 0.0

    now_utc = datetime.now(timezone.utc)
    # !!! WARNING: Using minutes for testing. Change to days for production. !!!
    cutoff = now_utc - timedelta(minutes=S3_OBJECT_AGE_DAYS_THRESHOLD) # Mins for testing
    logger.info(f"[{region}] Checking objects older than {cutoff.isoformat()}...")

    obj_ident=0; obj_del=0

    try:
        for bucket in s3_client.list_buckets().get('Buckets',[]):
            bname=bucket['Name']; tags=[]
            try:
                loc=s3_client.get_bucket_location(Bucket=bname).get('LocationConstraint'); bl=(loc if loc else 'us-east-1')
                if bl!=region: continue
                tags=s3_client.get_bucket_tagging(Bucket=bname).get('TagSet',[])
                if get_tag_value(tags, S3_CLEANUP_TAG_KEY)!=S3_CLEANUP_TAG_VALUE or is_excluded(tags): continue
            except ClientError as e:
                if e.response['Error']['Code']!='NoSuchTagSet': logger.warning(f"[{region}] S3 Prelim Fail ({bname}): {e}")
                continue # Skip if no tags, excluded, wrong tag, or other error

            logger.info(f"[{region}] Processing tagged bucket {bname}...")
            results['processed_buckets']+=1; bucket_obj_del_count=0
            try:
                vers=s3_client.get_bucket_versioning(Bucket=bname).get('Status')
                if vers=='Enabled': logger.warning(f"[{region}] Skipping versioned bucket {bname}."); continue

                paginator=s3_client.get_paginator('list_objects_v2'); batch=[]; batch_bytes=0
                for page in paginator.paginate(Bucket=bname):
                    for obj in page.get('Contents',[]):
                        if obj['LastModified'] < cutoff and not (obj['Key'].endswith('/') and obj.get('Size',0)==0):
                            batch.append({'Key':obj['Key']}); batch_bytes+=obj.get('Size',0); obj_ident+=1
                            if len(batch)>=1000:
                                sv=(batch_bytes/(1024**3))*S3_STANDARD_PRICE_GB_MONTH; results['savings']+=sv
                                if DRY_RUN: logger.info(f"[DRY RUN] Would del {len(batch)} batch from {bname}. Est ${sv:.2f}")
                                else:
                                    try: logger.info(f"Deleting {len(batch)} batch. Est ${sv:.2f}"); s3_client.delete_objects(Bucket=bname,Delete={'Objects':batch,'Quiet':True}); bucket_obj_del_count+=len(batch)
                                    except ClientError as e: results['errors'].append(f"S3BatchDelErr({bname}):{e}"); results['savings']-=sv
                                batch,batch_bytes=[],0 # Reset batch

                if batch: # Final batch
                    sv=(batch_bytes/(1024**3))*S3_STANDARD_PRICE_GB_MONTH; results['savings']+=sv
                    if DRY_RUN: logger.info(f"[DRY RUN] Would del {len(batch)} final batch from {bname}. Est ${sv:.2f}")
                    else:
                        try: logger.info(f"Deleting {len(batch)} final batch. Est ${sv:.2f}"); s3_client.delete_objects(Bucket=bname,Delete={'Objects':batch,'Quiet':True}); bucket_obj_del_count+=len(batch)
                        except ClientError as e: results['errors'].append(f"S3FinalDelErr({bname}):{e}"); results['savings']-=sv
            except ClientError as e: results['errors'].append(f"S3 List/Vers Err ({bname}):{e}")
            obj_del += bucket_obj_del_count # Aggregate actual deletes

        final_cnt=obj_ident if DRY_RUN else obj_del
        results["deleted_action"]["count"] = final_cnt
        # S3 details are just summary counts, not per-object for performance
        if final_cnt > 0:
            results["deleted_action"]["details"] = [f"{final_cnt} object(s) across {results['processed_buckets']} bucket(s)"]

        if results['processed_buckets']>0: logger.info(f"S3: Processed {results['processed_buckets']} buckets. {'Would del' if DRY_RUN else 'Deleted'} {final_cnt} objects.")
        else: logger.info(f"S3: No tagged buckets found.")
    except ClientError as e: results['errors'].append(f"S3 ListBuckets Err:{e}")
    logger.info(f"--- Finished S3 Optimization in {region} ---")
    return results, results['savings']

# --- optimize_lambda_functions (Corrected Version) ---
def optimize_lambda_functions(lambda_client, cloudwatch_client, region):
    logger.info(f"--- Starting Lambda Idle Reporting in {region} ---")
    results = {"errors": [], "idle_report": {"count": 0, "details": []}, "skipped": []}
    if not ENABLE_LAMBDA_IDLE_REPORTING:
        results["summary_lines"] = ["Lambda reporting disabled."]
        return results, 0.0

    now_utc = datetime.now(timezone.utc)
    idle_start_time = now_utc - timedelta(days=LAMBDA_IDLE_DAYS_THRESHOLD) # USE DAYS
    logger.info(f"[{region}] Checking Lambdas idle since {idle_start_time.isoformat()}...")
    idle_funcs_details = []

    try:
        paginator = lambda_client.get_paginator('list_functions')
        for page in paginator.paginate():
            for func in page.get('Functions', []):
                fname, arn, mod_str = func['FunctionName'], func['FunctionArn'], func['LastModified']
                mod_dt = datetime.strptime(mod_str, '%Y-%m-%dT%H:%M:%S.%f%z')
                if mod_dt > idle_start_time: continue # Skip recent

                tags = {}
                # --- CORRECTED TAG BLOCK ---
                try: tags = lambda_client.list_tags(Resource=arn).get('Tags',{})
                except ClientError as e: logger.warning(f"[{region}] Could not get tags for Lambda {fname}: {e}.")
                # --- END CORRECTED BLOCK ---

                if is_excluded(tags): results['skipped'].append(fname); continue

                try:
                    period = max(60, int(timedelta(days=LAMBDA_IDLE_DAYS_THRESHOLD).total_seconds())); period=min(period, 86400*30)
                    metrics = cloudwatch_client.get_metric_statistics( Namespace='AWS/Lambda', MetricName='Invocations', Dimensions=[{'Name':'FunctionName','Value':fname}], StartTime=idle_start_time, EndTime=now_utc, Period=period, Statistics=['Sum'], Unit='Count' )
                    invocations = sum(dp['Sum'] for dp in metrics['Datapoints'])
                    if invocations <= LAMBDA_IDLE_INVOCATION_THRESHOLD: idle_funcs_details.append(f"{fname} ({invocations} invocations)")
                except ClientError as e:
                    if e.response['Error']['Code'] == 'InvalidParameterValue' and mod_dt < idle_start_time: idle_funcs_details.append(f"{fname} (No invocations found)")
                    else: results['errors'].append(f"Lambda CW Err ({fname}): {e}")
                except Exception as e: results['errors'].append(f"Lambda Proc Err ({fname}): {e}")

        results['idle_report']['count'] = len(idle_funcs_details)
        results['idle_report']['details'] = idle_funcs_details
        if results['idle_report']['count'] > 0: logger.info(f"Found {results['idle_report']['count']} idle Lambdas.")

    except ClientError as e: results['errors'].append(f"List Functions Err: {e}")
    logger.info(f"--- Finished Lambda Idle Reporting in {region} ---")
    return results, 0.0

# --- optimize_eks_clusters (Corrected Version) ---
def optimize_eks_clusters(eks_client, region):
    logger.info(f"--- Starting EKS Cluster Unused Reporting in {region} ---")
    results = {"savings": 0.0, "errors": [], "unused_report": {"count": 0, "details": []}, "skipped": []}
    if not ENABLE_EKS_UNUSED_CLUSTER_REPORTING:
         results["summary_lines"] = ["EKS reporting disabled."]
         return results, 0.0

    eks_monthly_cost = EKS_CONTROL_PLANE_PRICE_HOURLY * 24 * 30.44
    unused_clusters_details = []

    try:
        paginator = eks_client.get_paginator('list_clusters')
        for page in paginator.paginate():
            for name in page.get('clusters', []):
                try:
                    clus = eks_client.describe_cluster(name=name)['cluster']
                    status, tags = clus.get('status'), clus.get('tags', {})
                    if status != 'ACTIVE': continue
                    if is_excluded(tags): results['skipped'].append(name); continue

                    nodegroups = eks_client.list_nodegroups(clusterName=name).get('nodegroups')
                    fargate = eks_client.list_fargate_profiles(clusterName=name).get('fargateProfileNames')
                    if not nodegroups and not fargate:
                        detail = f"{name} (Est ${eks_monthly_cost:.2f}/mo savings)"
                        unused_clusters_details.append(detail)
                        results['savings'] += eks_monthly_cost
                except ClientError as e: results['errors'].append(f"EKS Check Err ({name}): {e}")
                except Exception as e: results['errors'].append(f"EKS Proc Err ({name}): {e}")

        results['unused_report']['count'] = len(unused_clusters_details)
        results['unused_report']['details'] = unused_clusters_details
        if results['unused_report']['count'] > 0: logger.warning(f"Found {results['unused_report']['count']} potentially unused EKS clusters.")

    except ClientError as e: results['errors'].append(f"List EKS Err: {e}")
    logger.info(f"--- Finished EKS Cluster Unused Reporting in {region} ---")
    return results, results['savings']

# --- optimize_nat_gateways (Corrected Version) ---
def optimize_nat_gateways(ec2_client, cloudwatch_client, region):
    logger.info(f"--- Starting NAT Gateway Idle Reporting in {region} ---")
    results = { "savings": 0.0, "errors": [], "idle_report": {"count": 0, "details": []}, "skipped": [] }
    if not ENABLE_NAT_GATEWAY_IDLE_REPORTING:
        results["summary_lines"] = ["NAT GW reporting disabled."]
        return results, 0.0

    now_utc = datetime.now(timezone.utc)
    cutoff = now_utc - timedelta(days=NAT_IDLE_CHECK_DAYS) # USE DAYS
    logger.info(f"[{region}] Checking NAT GWs idle since {cutoff.isoformat()}...")
    nat_monthly_cost = NAT_GW_PRICE_HOURLY * 24 * 30.44
    idle_nat_details = []

    try:
        paginator = ec2_client.get_paginator('describe_nat_gateways')
        for page in paginator.paginate(Filter=[{'Name':'state','Values':['available']}]):
            for nat in page.get('NatGateways', []):
                nat_id, tags = nat['NatGatewayId'], nat.get('Tags', [])
                if is_excluded(tags): results['skipped'].append(nat_id); continue
                try:
                    metrics = cloudwatch_client.get_metric_statistics( Namespace='AWS/NATGateway', MetricName='BytesProcessed', Dimensions=[{'Name':'NatGatewayId','Value':nat_id}], StartTime=cutoff, EndTime=now_utc, Period=86400*NAT_IDLE_CHECK_DAYS, Statistics=['Sum'], Unit='Bytes' )
                    total_bytes = sum(dp['Sum'] for dp in metrics['Datapoints'])
                    if total_bytes < NAT_BYTES_PROCESSED_THRESHOLD:
                        gb_proc = total_bytes / (1024**3)
                        detail = f"{nat_id} ({gb_proc:.2f} GB processed) - Est ${nat_monthly_cost:.2f}/mo savings"
                        idle_nat_details.append(detail)
                        results['savings'] += nat_monthly_cost
                except ClientError as e: results['errors'].append(f"NAT Metric Err ({nat_id}): {e}")
                except Exception as e: results['errors'].append(f"NAT Proc Err ({nat_id}): {e}")

        results['idle_report']['count'] = len(idle_nat_details)
        results['idle_report']['details'] = idle_nat_details
        if results['idle_report']['count'] > 0: logger.info(f"Found {results['idle_report']['count']} potentially idle NAT GWs.")

    except ClientError as e: results['errors'].append(f"Desc NAT GW Err: {e}")
    logger.info(f"--- Finished NAT Gateway Idle Reporting in {region} ---")
    return results, results['savings']

# --- optimize_security_groups (Corrected Version) ---
def optimize_security_groups(ec2_client, region):
    logger.info(f"--- Starting Unused Security Group Reporting in {region} ---")
    results = { "errors": [], "unused_report": {"count": 0, "details": []}, "skipped": [] }
    if not ENABLE_UNUSED_SECURITY_GROUP_REPORTING:
        results["summary_lines"] = ["Unused SG reporting disabled."]
        return results, 0.0

    try:
        all_sgs={}; used_sgs=set(); unused_details = []
        paginator_sg = ec2_client.get_paginator('describe_security_groups')
        for page in paginator_sg.paginate():
            for sg in page.get('SecurityGroups', []):
                if sg.get('GroupName') != 'default': all_sgs[sg['GroupId']] = {'Name': sg['GroupName'], 'Tags': sg.get('Tags', [])}

        logger.info(f"[{region}] Found {len(all_sgs)} non-default SGs. Checking ENIs...")
        try:
            paginator_eni = ec2_client.get_paginator('describe_network_interfaces')
            for page in paginator_eni.paginate():
                for eni in page.get('NetworkInterfaces', []):
                    for group in eni.get('Groups', []): used_sgs.add(group['GroupId'])
        except ClientError as e: results['errors'].append(f"SG Check ENI Err: {e}")

        # Basic check: SG exists but wasn't found on any ENI
        for sg_id, sg_info in all_sgs.items():
            if sg_id not in used_sgs:
                 if not is_excluded(sg_info['Tags']):
                      unused_details.append(f"{sg_id}({sg_info['Name']})")
                 else:
                      results['skipped'].append(sg_id) # Track skipped

        results['unused_report']['count'] = len(unused_details)
        results['unused_report']['details'] = unused_details
        if results['unused_report']['count'] > 0: logger.info(f"Found {results['unused_report']['count']} potentially unused SGs.")

    except ClientError as e: results['errors'].append(f"Desc SG Err: {e}")
    except Exception as e: results['errors'].append(f"SG Assoc Check Err: {e}")
    logger.info(f"--- Finished Unused Security Group Reporting in {region} ---")
    return results, 0.0 # No savings


# --- Reporting and Notification Helpers ---

def upload_report_to_s3(s3_client, bucket_name, report_key, report_content):
    """Uploads the report to S3 (HTML) and generates a pre-signed URL."""
    try:
        report_bytes = report_content.encode('utf-8')
        s3_client.put_object( Bucket=bucket_name, Key=report_key, Body=report_bytes, ContentType="text/html; charset=utf-8" )
        logger.info(f"Report uploaded to S3: s3://{bucket_name}/{report_key}")
        presigned_url = s3_client.generate_presigned_url( 'get_object', Params={'Bucket': bucket_name, 'Key': report_key}, ExpiresIn=604800 )
        logger.debug(f"Generated pre-signed URL: {presigned_url}")
        return presigned_url
    except ClientError as e: logger.error(f"Error uploading report to S3/generating URL: {e}"); return f"s3://{bucket_name}/{report_key}"
    except Exception as e: logger.error(f"Unexpected error during S3 report upload: {e}"); raise

def send_sns_notification(sns_client, topic_arn, subject, message):
    """Sends a notification to the specified SNS topic."""
    try:
        response = sns_client.publish(TopicArn=topic_arn, Subject=subject, Message=message)
        logger.info(f"Notification sent to SNS {topic_arn}. Msg ID: {response.get('MessageId')}")
    except ClientError as e: logger.error(f"Error sending SNS notification: {e}")
    except Exception as e: logger.error(f"Unexpected error sending SNS: {e}")


# --- Main Handler ---

def lambda_handler(event, context):
    """Main Lambda execution entry point."""
    # Initialize savings variables including ALL processed services
    savings_totals = {
        "EC2": 0.0, "EBS": 0.0, "ELB": 0.0, "EIP": 0.0, "NAT Gateway": 0.0,
        "Security Group": 0.0, "CloudWatch Logs": 0.0, "CloudWatch Alarms": 0.0, # <<< ADDED CW Alarms
        "RDS": 0.0, "S3": 0.0, "Lambda": 0.0, "EKS": 0.0
    }
    all_regional_results = {} # Store structured results per region/service
    all_regional_errors = {}


    report_bucket_name = os.environ.get("REPORT_BUCKET_NAME")
    sns_topic_arn = os.environ.get("SNS_TOPIC_ARN")
    if not report_bucket_name or not sns_topic_arn:
        error_message = f"Missing required ENV VAR(s): {'REPORT_BUCKET_NAME ' if not report_bucket_name else ''}{'SNS_TOPIC_ARN' if not sns_topic_arn else ''}".strip()
        logger.error(error_message); return {"statusCode": 500, "body": json.dumps({"error": error_message})}

    logger.info("--- Starting Cloud Infra Cost Optimizer ---")
    start_time = datetime.now(timezone.utc)
    logger.info(f"Timestamp: {start_time.isoformat()}")
    if DRY_RUN: logger.warning("DRY RUN mode enabled.")
    else: logger.warning("DRY RUN mode disabled. CHANGES WILL BE APPLIED.")

    regions_to_process = TARGET_REGIONS if TARGET_REGIONS else [DEFAULT_REGION]
    logger.info(f"Target regions: {regions_to_process}")

    # --- Loop through Regions ---
    for region in regions_to_process:
        logger.info(f"--- Processing Region: {region} ---")
        region_start_time = datetime.now(timezone.utc)
        region_results_dict = {}
        region_errors = []
        try:
            session = boto3.Session(region_name=region)
            clients = {
                "ec2": session.client("ec2"), "elbv2": session.client("elbv2"), "cloudwatch": session.client("cloudwatch"),
                "logs": session.client("logs"), "rds": session.client("rds"), "s3": session.client("s3"),
                "lambda": session.client("lambda"), "eks": session.client("eks"), "compute-optimizer": session.client("compute-optimizer")
            }
            service_processing_map = {
                "EC2": (optimize_ec2, [clients["ec2"], clients["cloudwatch"], clients["compute-optimizer"], region]),
                "EBS": (optimize_ebs, [clients["ec2"], clients["cloudwatch"], region]),
                "ELB": (optimize_load_balancers, [clients["elbv2"], clients["cloudwatch"], region]),
                "EIP": (optimize_elastic_ips, [clients["ec2"], region]),
                "NAT Gateway": (optimize_nat_gateways, [clients["ec2"], clients["cloudwatch"], region]),
                "Security Group": (optimize_security_groups, [clients["ec2"], region]),
                "CloudWatch Logs": (optimize_cloudwatch_logs, [clients["logs"], region]),
                "CloudWatch Alarms": (report_cloudwatch_alarms, [clients["cloudwatch"], region]),
                "RDS": (optimize_rds, [clients["rds"], clients["cloudwatch"], region]),
                "S3": (optimize_s3, [clients["s3"], region]),
                "Lambda": (optimize_lambda_functions, [clients["lambda"], clients["cloudwatch"], region]),
                "EKS": (optimize_eks_clusters, [clients["eks"], region]),
            }
            for service_name, (func, args) in service_processing_map.items():
                srv_start = datetime.now(timezone.utc)
                logger.info(f"[{region}] Running {service_name} checks...")
                try:
                    result = func(*args)
                    if isinstance(result, tuple) and len(result) == 2: result_dict, savings = result
                    else: result_dict = result; savings = 0.0
                    if not isinstance(result_dict, dict): logger.error(f"[{region}] Invalid return type from {func.__name__}"); result_dict = {"errors": ["Invalid return type."]}
                    savings_totals[service_name] += savings
                    region_results_dict[service_name] = result_dict
                    if result_dict.get("errors"): region_errors.extend([f"{service_name}:{e}" for e in result_dict["errors"]])
                except Exception as e: logger.error(f"[{region}] UNHANDLED Error in {service_name}: {e}", exc_info=True); region_results_dict[service_name] = {"errors": [f"Unhandled Exception: {e}"]}; region_errors.append(f"{service_name}:Unhandled:{e}")
                logger.info(f"[{region}] Finished {service_name}. Duration: {datetime.now(timezone.utc) - srv_start}")
            all_regional_results[region] = region_results_dict
        except (ClientError, NoCredentialsError, PartialCredentialsError) as e: logger.error(f"!!! AWS Client/Credential error processing region {region}: {e}", exc_info=True); all_regional_results[region] = {"Error": f"AWS Client/Credential Error: {e}"}; region_errors.append(f"Client/Cred Error:{e}")
        except Exception as e: logger.error(f"!!! Unexpected error processing region {region} setup: {e}", exc_info=True); all_regional_results[region] = {"Error": f"Setup Error: {e}"}; region_errors.append(f"Setup Error:{e}")
        if region_errors: all_regional_errors[region] = region_errors
        logger.info(f"--- Finished processing region {region}. Duration: {datetime.now(timezone.utc) - region_start_time} ---")

    # --- Aggregated Metrics ---
    total_regions_processed = len(regions_to_process); total_errors_count = sum(len(v) for v in all_regional_errors.values())
    total_savings = sum(max(0, v) for v in savings_totals.values())
    chart_labels = ["EC2", "EBS", "ELB", "EIP", "NAT GW", "SG", "CW Logs", "RDS", "S3", "Lambda", "EKS"]
    chart_values = [ max(0, savings_totals.get(label.replace("NAT GW","NAT Gateway").replace("SG","Security Group"), 0.0)) for label in chart_labels ]
    savings_data_for_js = {"labels": chart_labels, "values": chart_values}; savings_json_str = json.dumps(savings_data_for_js)

    # --- Build HTML Report ---
    html_lines = [ "<!DOCTYPE html><html lang='en'><head><meta charset='UTF-8'>", "<title>Cloud Infra Cost Optimizer Report</title>", "<script src='https://cdn.jsdelivr.net/npm/chart.js'></script>", "<style>body{font-family:system-ui,sans-serif;margin:20px;line-height:1.5;background-color:#f8f9fa;color:#212529}h1,h2,h3,h4{color:#007bff;margin-top:1.5em;margin-bottom:0.5em}h1{text-align:center;border-bottom:2px solid #dee2e6;padding-bottom:10px}.meta-info{text-align:center;margin-bottom:2em;color:#6c757d}.region-summary{background-color:#fff;border:1px solid #dee2e6;border-radius:5px;padding:15px;margin-bottom:20px;box-shadow:0 1px 3px rgba(0,0,0,0.1)}.region-summary h3{color:#17a2b8;margin-top:0;border-bottom:1px solid #eee;padding-bottom:5px}.service-details{margin-left:1em; border-left: 3px solid #eee; padding-left: 1em; margin-bottom: 1em;} .service-details h4{color:#6c757d; margin-top: 1em; font-size: 1.1em; margin-bottom: 0.3em;} .summary-section{margin-top:30px;padding:20px;background-color:#fff;border:1px solid #dee2e6;border-radius:5px}pre{background-color:#e9ecef;padding:5px 8px;border:1px solid #ced4da;border-radius:4px;white-space:pre-wrap;word-wrap:break-word;font-size:0.9em;margin-top:5px;margin-bottom:5px;}strong{color:#495057}ul{list-style:none; margin-left:0; padding-left: 5px;} li{margin-bottom:3px;} .notes{font-size:0.9em;color:#6c757d;margin-top:20px;border-top:1px solid #eee;padding-top:10px}.chart-container{max-width:800px;margin:20px auto;height:450px;}</style>", "</head><body>", "<h1>Cloud Infra Cost Optimizer Report</h1>", f"<div class='meta-info'><strong>Execution Time:</strong> {start_time.isoformat()}<br/><strong>DRY RUN Mode:</strong> {DRY_RUN}</div>", "<h2>Regional Details</h2>" ]
    if all_regional_results:
        for region, region_data in all_regional_results.items():
            html_lines.append(f"<div class='region-summary'><h3>Region: {region}</h3>")
            if "Error" in region_data: html_lines.append(f"<pre style='color: red;'><strong>Error:</strong> {region_data['Error']}</pre>")
            else:
                service_order = ["EC2", "EBS", "ELB", "EIP", "NAT Gateway", "Security Group", "CloudWatch Logs", "CloudWatch Alarms", "RDS", "S3", "Lambda", "EKS"]
                for service in service_order:
                    if service in region_data:
                        service_result = region_data[service]; html_lines.append(f"<div class='service-details'><h4>{service}</h4>")
                        def format_details_list_html(data_dict, key, title, limit=10):
                            items = data_dict.get(key, {}).get('details', [])
                            count = data_dict.get(key, {}).get('count', len(items))
                            lines = []
                            if count > 0:
                                lines.append(f"<p><strong>{title}:</strong> {count} item(s)</p><ul>")
                                for detail in items[:limit]: lines.append(f"<li><pre>{str(detail).replace('<','<')}</pre></li>")
                                if len(items) > limit: lines.append("<li>...</li>")
                                lines.append("</ul>")
                            else: lines.append(f"<p><strong>{title}:</strong> None found/identified.</p>")
                            return lines

                        if service == "EC2":
                            action = "Would Terminate" if DRY_RUN else "Terminated"; html_lines.extend(format_details_list_html(service_result, 'terminated_action', action))
                            html_lines.extend(format_details_list_html(service_result, 'older_gen_report', "Older Generation Report"))
                            html_lines.extend(format_details_list_html(service_result, 'compute_optimizer_report', "Compute Optimizer Report"))
                        elif service == "EBS":
                            action_del = "Would Delete" if DRY_RUN else "Deleted"; action_conv = "Would Convert" if DRY_RUN else "Converted"
                            html_lines.extend(format_details_list_html(service_result, 'deleted_vol_action', f"{action_del} Available Volumes"))
                            html_lines.extend(format_details_list_html(service_result, 'converted_vol_action', f"{action_conv} Volumes (gp2->gp3)"))
                            html_lines.extend(format_details_list_html(service_result, 'deleted_snap_action', f"{action_del} Old Snapshots"))
                            html_lines.extend(format_details_list_html(service_result, 'idle_vol_report', "Potentially Idle Volumes Report"))
                        elif service == "RDS":
                            action_mod = "Would Modify" if DRY_RUN else "Modified"; action_del = "Would Delete" if DRY_RUN else "Deleted"
                            html_lines.extend(format_details_list_html(service_result, 'modified_inst_ret_action', f"{action_mod} Instance Retention"))
                            html_lines.extend(format_details_list_html(service_result, 'modified_clus_ret_action', f"{action_mod} Cluster Retention"))
                            html_lines.extend(format_details_list_html(service_result, 'deleted_inst_snap_action', f"{action_del} Instance Snapshots"))
                            html_lines.extend(format_details_list_html(service_result, 'deleted_clus_snap_action', f"{action_del} Cluster Snapshots"))
                            html_lines.extend(format_details_list_html(service_result, 'low_cpu_report', "Low CPU Instances Report"))
                        elif service == "ELB": html_lines.extend(format_details_list_html(service_result, 'deleted_action', "Would Delete Idle LBs" if DRY_RUN else "Deleted Idle LBs"))
                        elif service == "EIP": html_lines.extend(format_details_list_html(service_result, 'released_action', "Would Release Unattached EIPs" if DRY_RUN else "Released Unattached EIPs"))
                        elif service == "NAT Gateway": html_lines.extend(format_details_list_html(service_result, 'idle_report', "Potentially Idle NAT Gateways Report"))
                        elif service == "Security Group": html_lines.extend(format_details_list_html(service_result, 'unused_report', "Potentially Unused Security Groups Report"))
                        elif service == "CloudWatch Logs": html_lines.extend(format_details_list_html(service_result, 'modified_action', "Log Groups Retention Update"))
                        elif service == "CloudWatch Alarms": html_lines.extend(format_details_list_html(service_result, 'insufficient_data_report', "Long Insufficient Data Alarms Report"))
                        elif service == "S3": html_lines.extend(format_details_list_html(service_result, 'deleted_action', "Objects Deleted/Identified")) # Special S3 summary detail
                        elif service == "Lambda": html_lines.extend(format_details_list_html(service_result, 'idle_report', "Potentially Idle Functions Report"))
                        elif service == "EKS": html_lines.extend(format_details_list_html(service_result, 'unused_report', "Potentially Unused Clusters Report"))

                        if service_result.get("errors"):
                            html_lines.append("<p style='color:orange;'><strong>Service Errors:</strong></p><ul>")
                            for err in service_result["errors"][:3]: html_lines.append(f"<li><pre>{str(err).replace('<','<')}</pre></li>")
                            if len(service_result["errors"]) > 3: html_lines.append("<li>...</li>")
                            html_lines.append("</ul>")
                        html_lines.append("</div>") # End Service Details
            html_lines.append("</div>") # End Region Summary
    else: html_lines.append("<p>No regions processed.</p>")

    # Overall Summary and Chart Section
    html_lines.extend([ "<div class='summary-section'><h2>Overall Summary</h2>", f"<p><strong>Total Regions Processed:</strong> {total_regions_processed}</p>", f"<p><strong>Total Errors Encountered:</strong> {total_errors_count}</p>" ])
    if total_errors_count > 0: html_lines.append("<p><strong>Errors Summary:</strong></p><ul>"); [html_lines.append(f"<li>{r}: {len(e)} error(s)</li>") for r, e in all_regional_errors.items()]; html_lines.append("</ul>")
    html_lines.extend([ "<h2>Savings Breakdown</h2>", "<div class='chart-container'><canvas id='savingsBarChart'></canvas></div>", f"<p style='text-align: center; font-size: 1.2em;'><strong>Total Estimated Savings: ${total_savings:.2f}</strong></p>", "</div>" ])

    # Notes Section
    html_lines.append("<div class='notes'>")
    if DRY_RUN: html_lines.append("<p>Note: Savings are estimated based on DRY RUN mode.</p>")
    def check_svc_processed(svc): return any(svc in r and "Error" not in r[svc] for r in all_regional_results.values() if isinstance(r, dict))
    if check_svc_processed("CloudWatch Logs"): html_lines.append("<p>Note: CW Logs savings reported as $0.00; actual savings vary.</p>")
    if check_svc_processed("Lambda"): html_lines.append("<p>Note: Lambda reports potentially idle functions ($0.00 savings reported).</p>")
    if check_svc_processed("EKS"): html_lines.append("<p>Note: EKS savings estimate for control plane cost of potentially unused clusters. Verify manually.</p>")
    if check_svc_processed("NAT Gateway"): html_lines.append("<p>Note: NAT GW savings estimate for hourly cost of potentially idle gateways. Verify manually.</p>")
    if check_svc_processed("Security Group"): html_lines.append("<p>Note: Unused SG check is basic; requires manual verification.</p>")
    if check_svc_processed("EC2"): html_lines.append("<p>Note: EC2 includes Compute Optimizer/Older Gen reports.</p>")
    if check_svc_processed("EBS"): html_lines.append("<p>Note: EBS includes idle volume reporting.</p>")
    if check_svc_processed("RDS"): html_lines.append("<p>Note: RDS includes low CPU reporting.</p>")
    html_lines.append("</div>")

    # Embedded JavaScript for Chart
    html_lines.append("<script>")
    html_lines.append(f"const savingsData = {savings_json_str};")
    html_lines.append("const ctxBar = document.getElementById('savingsBarChart').getContext('2d');")
    html_lines.append("new Chart(ctxBar, { type: 'bar', data: {")
    html_lines.append("  labels: savingsData.labels, datasets: [{")
    html_lines.append("    label: 'Estimated Monthly Savings ($)', data: savingsData.values,")
    html_lines.append("    backgroundColor: ['#D9534F', '#5BC0DE', '#F0AD4E', '#5CB85C', '#FFB04E', '#7E827A', '#6E54D9', '#0275D8', '#F7AC49', '#FF9900', '#232F3E', '#8C8C8C'],")
    html_lines.append("    borderColor: '#fff', borderWidth: 1")
    html_lines.append("}]}, options: { indexAxis: 'y', scales: { x: { beginAtZero: true, title: { display: true, text: 'USD ($) per Month' } } }, responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false }, title: { display: true, text: 'Estimated Savings Breakdown by Service', font: { size: 16 } } } } });")
    html_lines.append("</script>")
    html_lines.append("</body></html>")
    html_content = "\n".join(html_lines)

    # --- Finalize and Upload Report ---
    report_url = f"s3://{report_bucket_name}/UNKNOWN_REPORT_KEY.html"
    try:
        s3_client_upload = boto3.client("s3"); report_time_str = start_time.strftime('%Y-%m-%dT%H-%M-%SZ')
        report_key = f"{os.environ.get('REPORT_KEY_PREFIX', 'cost-optimizer-reports/')}{report_time_str}-report.html"
        report_url = upload_report_to_s3(s3_client_upload, report_bucket_name, report_key, html_content)
    except Exception as e: logger.error(f"Failed to upload report to S3: {e}", exc_info=True)

    # --- Send SNS Notification ---
    try:
        sns_client = boto3.client("sns"); action_desc = 'DRY RUN' if DRY_RUN else 'ACTION TAKEN'
        sns_subject = f"Cost Optimizer Report ({action_desc}) - ${total_savings:.2f} Savings Est"
        sns_message = ( f"Optimizer execution completed.\n\nMode: {action_desc}\nTime: {start_time.isoformat()}\n"
                        f"Total Savings Est: ${total_savings:.2f}\nRegions: {total_regions_processed}, Errors: {total_errors_count}\n\n"
                        f"Report: {report_url}" )
        send_sns_notification(sns_client, sns_topic_arn, sns_subject, sns_message)
    except Exception as e: logger.error(f"Failed to send SNS notification: {e}", exc_info=True)

    end_time = datetime.now(timezone.utc)
    logger.info(f"--- Cloud Infra Cost Optimizer execution finished. Total Duration: {end_time - start_time} ---")

    return { "statusCode": 200, "body": json.dumps({ "message": f"Run complete. Report: {report_url}", "totalSavings": total_savings, "dryRun": DRY_RUN, "errors": total_errors_count }) }

# --- End of File ---