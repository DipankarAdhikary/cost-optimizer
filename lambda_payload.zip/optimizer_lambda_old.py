import boto3
import os
import logging
import json
from datetime import datetime, timezone, timedelta
from botocore.exceptions import ClientError, NoCredentialsError, PartialCredentialsError
from statistics import mean # For rightsizing checks

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO) # Change to DEBUG for more verbose logs

# --- Configuration from Environment Variables ---
DRY_RUN = os.environ.get('DRY_RUN', 'true').lower() == 'true'
TARGET_REGIONS_STR = os.environ.get("TARGET_REGIONS", "us-east-1")
TARGET_REGIONS = [region.strip() for region in TARGET_REGIONS_STR.split(',') if region.strip()]
DEFAULT_REGION = os.environ.get('AWS_REGION', 'us-east-1')

# --- Service-Specific Enablement & Thresholds ---
# EC2
ENABLE_EC2_TERMINATION = os.environ.get('ENABLE_EC2_TERMINATION', 'true').lower() == 'true'
EC2_STOPPED_DAYS_THRESHOLD = int(os.environ.get('EC2_STOPPED_DAYS_THRESHOLD', '7')) # MINS FOR TEST
ENABLE_EC2_OPTIMIZATION_REPORTING = os.environ.get('ENABLE_EC2_OPTIMIZATION_REPORTING', 'true').lower() == 'true'
EC2_LOW_CPU_THRESHOLD_PERCENT = int(os.environ.get('EC2_LOW_CPU_THRESHOLD_PERCENT', '10')) # Avg CPU below this
EC2_RIGHTSIZE_CHECK_DAYS = int(os.environ.get('EC2_RIGHTSIZE_CHECK_DAYS', '14')) # Period for CPU check

# EBS
ENABLE_EBS_GP2_TO_GP3_CONVERSION = os.environ.get('ENABLE_EBS_GP2_TO_GP3_CONVERSION', 'true').lower() == 'true'
ENABLE_EBS_GP2_TO_GP3_CONVERSION_FOR_ROOT = os.environ.get('ENABLE_EBS_GP2_TO_GP3_CONVERSION_FOR_ROOT', 'false').lower() == 'true'
ENABLE_EBS_AVAILABLE_VOLUME_DELETION = os.environ.get('ENABLE_EBS_AVAILABLE_VOLUME_DELETION', 'true').lower() == 'true'
ENABLE_EBS_SNAPSHOT_DELETION = os.environ.get('ENABLE_EBS_SNAPSHOT_DELETION', 'true').lower() == 'true'
EBS_SNAPSHOT_RETENTION_DAYS = int(os.environ.get('EBS_SNAPSHOT_RETENTION_DAYS', '30')) # MINS FOR TEST
ENABLE_EBS_IDLE_VOLUME_REPORTING = os.environ.get('ENABLE_EBS_IDLE_VOLUME_REPORTING', 'true').lower() == 'true'
EBS_IDLE_TIME_THRESHOLD_PERCENT = int(os.environ.get('EBS_IDLE_TIME_THRESHOLD_PERCENT', '99')) # Avg VolumeIdleTime % above this
EBS_IDLE_CHECK_DAYS = int(os.environ.get('EBS_IDLE_CHECK_DAYS', '14')) # Period for idle check

# ELB
ENABLE_ELB_DELETION = os.environ.get('ENABLE_ELB_DELETION', 'true').lower() == 'true'
ELB_IDLE_DAYS_THRESHOLD = int(os.environ.get('ELB_IDLE_DAYS_THRESHOLD', '30')) # MINS FOR TEST

# EIP
ENABLE_EIP_RELEASE = os.environ.get('ENABLE_EIP_RELEASE', 'true').lower() == 'true'
UNATTACHED_EIP_PRICE_HOURLY = 0.005

# CW Logs
ENABLE_CW_LOG_GROUP_RETENTION_MANAGEMENT = os.environ.get('ENABLE_CW_LOG_GROUP_RETENTION_MANAGEMENT', 'true').lower() == 'true'
CW_LOG_GROUP_RETENTION_PROD_UAT_DAYS = int(os.environ.get('CW_LOG_GROUP_RETENTION_PROD_UAT_DAYS', '90'))
CW_LOG_GROUP_RETENTION_DEV_DAYS = int(os.environ.get('CW_LOG_GROUP_RETENTION_DEV_DAYS', '7'))
CW_LOG_GROUP_RETENTION_DEFAULT_DAYS = int(os.environ.get('CW_LOG_GROUP_RETENTION_DEFAULT_DAYS', '30'))
ENVIRONMENT_TAG_KEY = os.environ.get('ENVIRONMENT_TAG_KEY', 'Environment')
ENV_VALUES_PROD = [v.strip().lower() for v in os.environ.get('ENVIRONMENT_VALUES_PROD', 'prod,production').split(',')]
ENV_VALUES_UAT = [v.strip().lower() for v in os.environ.get('ENVIRONMENT_VALUES_UAT', 'uat,staging,stage,test').split(',')]
ENV_VALUES_DEV = [v.strip().lower() for v in os.environ.get('ENVIRONMENT_VALUES_DEV', 'dev,development').split(',')]
CW_LOG_STORAGE_PRICE_GB_MONTH = 0.03

# CW Alarms
ENABLE_CW_INSUFFICIENT_DATA_ALARM_REPORTING = os.environ.get('ENABLE_CW_INSUFFICIENT_DATA_ALARM_REPORTING', 'true').lower() == 'true'
CW_ALARM_INSUFFICIENT_DATA_DAYS_THRESHOLD = int(os.environ.get('CW_ALARM_INSUFFICIENT_DATA_DAYS_THRESHOLD', '30')) # MINS FOR TEST

# RDS
ENABLE_RDS_BACKUP_RETENTION_ADJUSTMENT = os.environ.get('ENABLE_RDS_BACKUP_RETENTION_ADJUSTMENT', 'true').lower() == 'true'
RDS_MAX_BACKUP_RETENTION_DAYS = int(os.environ.get('RDS_MAX_BACKUP_RETENTION_DAYS', '7'))
ENABLE_RDS_MANUAL_SNAPSHOT_DELETION = os.environ.get('ENABLE_RDS_MANUAL_SNAPSHOT_DELETION', 'true').lower() == 'true'
RDS_MANUAL_SNAPSHOT_RETENTION_DAYS = int(os.environ.get('RDS_MANUAL_SNAPSHOT_RETENTION_DAYS', '7')) # MINS FOR TEST
ENABLE_RDS_LOW_CPU_REPORTING = os.environ.get('ENABLE_RDS_LOW_CPU_REPORTING', 'true').lower() == 'true'
RDS_LOW_CPU_THRESHOLD_PERCENT = int(os.environ.get('RDS_LOW_CPU_THRESHOLD_PERCENT', '10')) # Avg CPU below this
RDS_RIGHTSIZE_CHECK_DAYS = int(os.environ.get('RDS_RIGHTSIZE_CHECK_DAYS', '14')) # Period for CPU check
RDS_SNAPSHOT_PRICE_GB_MONTH = 0.05

# S3
ENABLE_S3_OBJECT_DELETION = os.environ.get('ENABLE_S3_OBJECT_DELETION', 'false').lower() == 'true'
S3_CLEANUP_TAG_KEY = os.environ.get('S3_CLEANUP_TAG_KEY', 'cost-optimizer-cleanup-objects')
S3_CLEANUP_TAG_VALUE = os.environ.get('S3_CLEANUP_TAG_VALUE', 'true')
S3_OBJECT_AGE_DAYS_THRESHOLD = int(os.environ.get('S3_OBJECT_AGE_DAYS_THRESHOLD', '30')) # MINS FOR TEST
S3_STANDARD_PRICE_GB_MONTH = 0.023

# Lambda
ENABLE_LAMBDA_IDLE_REPORTING = os.environ.get('ENABLE_LAMBDA_IDLE_REPORTING', 'true').lower() == 'true'
LAMBDA_IDLE_DAYS_THRESHOLD = int(os.environ.get('LAMBDA_IDLE_DAYS_THRESHOLD', '30')) # USE DAYS
LAMBDA_IDLE_INVOCATION_THRESHOLD = int(os.environ.get('LAMBDA_IDLE_INVOCATION_THRESHOLD', '5'))

# EKS
ENABLE_EKS_UNUSED_CLUSTER_REPORTING = os.environ.get('ENABLE_EKS_UNUSED_CLUSTER_REPORTING', 'true').lower() == 'true'
EKS_CONTROL_PLANE_PRICE_HOURLY = 0.10

# NAT Gateway (NEW)
ENABLE_NAT_GATEWAY_IDLE_REPORTING = os.environ.get('ENABLE_NAT_GATEWAY_IDLE_REPORTING', 'true').lower() == 'true'
NAT_IDLE_CHECK_DAYS = int(os.environ.get('NAT_IDLE_CHECK_DAYS', '30')) # USE DAYS
NAT_BYTES_PROCESSED_THRESHOLD = int(os.environ.get('NAT_BYTES_PROCESSED_THRESHOLD', 1 * 1024**3)) # Bytes (e.g., 1 GB)
NAT_GW_PRICE_HOURLY = 0.045 # Varies by region, check pricing

# Security Groups (NEW)
ENABLE_UNUSED_SECURITY_GROUP_REPORTING = os.environ.get('ENABLE_UNUSED_SECURITY_GROUP_REPORTING', 'true').lower() == 'true'

# Exclusion Tag
EXCLUDE_TAG_KEY = os.environ.get('OPTIMIZATION_EXCLUDE_TAG_KEY', 'cost-optimizer-exclude')
EXCLUDE_TAG_VALUE = os.environ.get('OPTIMIZATION_EXCLUDE_TAG_VALUE', 'true')


# --- Helper Functions ---

def is_excluded(tags):
    """Checks if a resource has the exclusion tag. Handles list or dict."""
    if not tags: return False
    tag_list = tags
    if isinstance(tags, dict): tag_list = [{'Key': k, 'Value': v} for k, v in tags.items()]
    if not isinstance(tag_list, list): logger.warning(f"Unexpected tag format: {type(tag_list)}."); return False
    for tag in tag_list:
        if isinstance(tag, dict) and tag.get('Key') == EXCLUDE_TAG_KEY and tag.get('Value') == EXCLUDE_TAG_VALUE: return True
    return False

def get_tag_value(tags, key):
    """Gets the value of a specific tag key from a list or dict of tags."""
    if not tags or not key: return None
    tag_list = tags
    if isinstance(tags, dict): tag_list = [{'Key': k, 'Value': v} for k, v in tags.items()]
    if not isinstance(tag_list, list): logger.warning(f"Unexpected tag format: {type(tag_list)}."); return None
    for tag in tag_list:
       if isinstance(tag, dict) and tag.get('Key') == key: return tag.get('Value')
    return None

# --- Pricing Helper Functions ---

def get_ec2_instance_price(instance_type, region):
    
    pricing_client = boto3.client('pricing', region_name='us-east-1')
    region_mapping = { 'us-east-1': 'US East (N. Virginia)', 'eu-west-1': 'EU (Ireland)' }
    location = region_mapping.get(region, region)
    try:
        response = pricing_client.get_products( ServiceCode='AmazonEC2', Filters=[ {'Type': 'TERM_MATCH', 'Field': 'instanceType', 'Value': instance_type}, {'Type': 'TERM_MATCH', 'Field': 'location', 'Value': location}, {'Type': 'TERM_MATCH', 'Field': 'operatingSystem', 'Value': 'Linux'}, {'Type': 'TERM_MATCH', 'Field': 'preInstalledSw', 'Value': 'NA'}, {'Type': 'TERM_MATCH', 'Field': 'tenancy', 'Value': 'Shared'}, {'Type': 'TERM_MATCH', 'Field': 'capacitystatus', 'Value': 'Used'} ], MaxResults=1 )
        price_list = response.get('PriceList', [])
        if price_list:
            price_item = json.loads(price_list[0]); terms = price_item.get('terms', {}).get('OnDemand', {})
            if terms: term_key = list(terms.keys())[0]; price_dimensions = terms[term_key].get('priceDimensions', {}); price_key = list(price_dimensions.keys())[0]; price_value = price_dimensions[price_key].get('pricePerUnit', {}).get('USD')
            if price_value: return float(price_value)
        logger.warning(f"Could not parse EC2 price for {instance_type} in {region}")
        return None
    except (ClientError, KeyError, IndexError, ValueError, TypeError, json.JSONDecodeError) as e:
        logger.error(f"Error fetching/parsing EC2 pricing for {instance_type} in {region}: {e}")
        return None

def get_ebs_price(volume_type, region):
    
     pricing_client = boto3.client('pricing', region_name='us-east-1')
     region_mapping = { 'us-east-1': 'US East (N. Virginia)', 'eu-west-1': 'EU (Ireland)' }
     location = region_mapping.get(region, region)
     try:
         response = pricing_client.get_products( ServiceCode='AmazonEC2', Filters=[ {'Type': 'TERM_MATCH', 'Field': 'volumeApiName', 'Value': volume_type}, {'Type': 'TERM_MATCH', 'Field': 'location', 'Value': location} ], MaxResults=1 )
         price_list = response.get('PriceList', [])
         if price_list:
             price_item = json.loads(price_list[0]); terms = price_item.get('terms', {}).get('OnDemand', {})
             if terms: term_key = list(terms.keys())[0]; price_dimensions = terms[term_key].get('priceDimensions', {}); price_key = list(price_dimensions.keys())[0]; price_value = price_dimensions[price_key].get('pricePerUnit', {}).get('USD')
             if price_value: return float(price_value)
         logger.warning(f"Could not parse EBS price for {volume_type} in {region}")
         return None
     except (ClientError, KeyError, IndexError, ValueError, TypeError, json.JSONDecodeError) as e:
         logger.error(f"Error fetching/parsing EBS pricing for {volume_type} in {region}: {e}")
         return None

def get_ebs_snapshot_price(region):
     # ... (implementation from previous full code) ...
     pricing_client = boto3.client('pricing', region_name='us-east-1')
     region_mapping = { 'us-east-1': 'US East (N. Virginia)', 'eu-west-1': 'EU (Ireland)' }
     location = region_mapping.get(region, region)
     region_prefix_map = { 'us-east-1': 'USE1', 'eu-west-1': 'EU' }
     usage_type_prefix = region_prefix_map.get(region, region.upper().replace('-', ''))
     usage_type = f"{usage_type_prefix}-SnapshotUsage"
     price_value = None
     try:
         response = pricing_client.get_products( ServiceCode='AmazonEC2', Filters=[ {'Type': 'TERM_MATCH', 'Field': 'productFamily', 'Value': 'Storage Snapshot'}, {'Type': 'TERM_MATCH', 'Field': 'location', 'Value': location}, {'Type': 'TERM_MATCH', 'Field': 'usagetype', 'Value': usage_type} ], MaxResults=1 )
         price_list = response.get('PriceList', [])
         if price_list:
              price_item = json.loads(price_list[0]); terms = price_item.get('terms', {}).get('OnDemand', {})
              if terms: term_key = list(terms.keys())[0]; price_dimensions = terms[term_key].get('priceDimensions', {}); price_key = list(price_dimensions.keys())[0]; price_str = price_dimensions[price_key].get('pricePerUnit', {}).get('USD')
              if price_str: price_value = float(price_str)
         if price_value is None:
             logger.warning(f"Snapshot price not found with usage type {usage_type}, trying generic filter.")
             response = pricing_client.get_products( ServiceCode='AmazonEC2', Filters=[ {'Type': 'TERM_MATCH', 'Field': 'productFamily', 'Value': 'Storage Snapshot'}, {'Type': 'TERM_MATCH', 'Field': 'location', 'Value': location} ], MaxResults=1 )
             price_list = response.get('PriceList', [])
             if price_list:
                  price_item = json.loads(price_list[0]); terms = price_item.get('terms', {}).get('OnDemand', {})
                  if terms: term_key = list(terms.keys())[0]; price_dimensions = terms[term_key].get('priceDimensions', {}); price_key = list(price_dimensions.keys())[0]; price_str = price_dimensions[price_key].get('pricePerUnit', {}).get('USD')
                  if price_str: price_value = float(price_str)
         if price_value is None: logger.warning(f"Could not parse EBS snapshot price for {region}")
         return price_value
     except (ClientError, KeyError, IndexError, ValueError, TypeError, json.JSONDecodeError) as e:
         logger.error(f"Error fetching/parsing EBS snapshot pricing for {region}: {e}")
         return None

def get_elb_price(lb_type, region):
     # ... (implementation from previous full code) ...
     pricing_client = boto3.client('pricing', region_name='us-east-1')
     region_mapping = { 'us-east-1': 'US East (N. Virginia)', 'eu-west-1': 'EU (Ireland)' }
     location = region_mapping.get(region, region)
     product_family_map = { 'application': 'Load Balancer-Application', 'network': 'Load Balancer-Network', 'gateway': 'Load Balancer-Gateway' }
     product_family = product_family_map.get(lb_type)
     if not product_family: return None
     region_prefix_map = { 'us-east-1': 'USE1', 'eu-west-1': 'EU' }
     usage_type_prefix = region_prefix_map.get(region, region.upper().replace('-', ''))
     usage_type_attempts = [ f"{usage_type_prefix}-LoadBalancerUsage", "LoadBalancerUsage" ]
     price_value = None
     try:
         for usage_type in usage_type_attempts:
             response = pricing_client.get_products( ServiceCode='AWSELB', Filters=[ {'Type': 'TERM_MATCH', 'Field': 'productFamily', 'Value': product_family}, {'Type': 'TERM_MATCH', 'Field': 'location', 'Value': location}, {'Type': 'TERM_MATCH', 'Field': 'usagetype', 'Value': usage_type} ], MaxResults=1 )
             price_list = response.get('PriceList', [])
             if price_list:
                 price_item = json.loads(price_list[0]); terms = price_item.get('terms', {}).get('OnDemand', {})
                 if terms: term_key = list(terms.keys())[0]; price_dimensions = terms[term_key].get('priceDimensions', {}); price_key = list(price_dimensions.keys())[0]; price_str = price_dimensions[price_key].get('pricePerUnit', {}).get('USD')
                 if price_str: price_value = float(price_str); break
             if price_value is not None: break
         if price_value is None: logger.warning(f"Could not parse ELB price for {lb_type} in {region}")
         return price_value
     except (ClientError, KeyError, IndexError, ValueError, TypeError, json.JSONDecodeError) as e:
         logger.error(f"Error fetching/parsing pricing for {lb_type} Load Balancer in {region}: {e}")
         return None

# --- Service Specific Optimization Functions ---

def optimize_ec2(ec2_client, cloudwatch_client, region):
    """Optimize EC2: Terminate old stopped, report old gen, report low CPU."""
    logger.info(f"--- Starting EC2 Optimization in {region} ---")
    now_utc = datetime.now(timezone.utc)
    results = { "savings": 0.0, "errors": [], "summary_lines": [],
                "would_terminate": [], "terminated": [],
                "older_gen": [], "low_cpu": [] }

    # --- 1. Terminate old stopped instances ---
    if ENABLE_EC2_TERMINATION:
        try:
            # !!! WARNING: Using minutes for testing. Change to days for production. !!!
            stopped_cutoff_time = now_utc - timedelta(minutes=EC2_STOPPED_DAYS_THRESHOLD)
            logger.info(f"[{region}] Checking instances stopped before {stopped_cutoff_time.isoformat()}...")
            paginator = ec2_client.get_paginator("describe_instances")
            page_iterator = paginator.paginate(Filters=[{"Name": "instance-state-name", "Values": ["stopped"]}])
            instances_to_terminate_candidates = []

            for page in page_iterator:
                for reservation in page["Reservations"]:
                    for instance in reservation["Instances"]:
                        instance_id, tags = instance["InstanceId"], instance.get("Tags", [])
                        if is_excluded(tags): continue
                        stopped_time = instance.get("UsageOperationUpdateTime")
                        if not stopped_time: # Fallback logic
                             reason = instance.get('StateTransitionReason', ''); stopped_time = instance["LaunchTime"]
                             if 'User initiated' in reason:
                                 try: stopped_time = datetime.strptime(reason.split('(')[-1].split(' GMT)')[0], '%Y-%m-%d %H:%M:%S').replace(tzinfo=timezone.utc)
                                 except: pass
                        if stopped_time < stopped_cutoff_time:
                            instances_to_terminate_candidates.append({
                                "id": instance_id, "type": instance["InstanceType"], "stopped_time": stopped_time
                            })

            logger.info(f"[{region}] Found {len(instances_to_terminate_candidates)} candidate(s) for termination.")
            for inst_info in instances_to_terminate_candidates:
                 inst_id, inst_type = inst_info['id'], inst_info['type']
                 hourly_price = get_ec2_instance_price(inst_type, region)
                 monthly_savings = (hourly_price * 24 * 30.44) if hourly_price else 0.0
                 results['savings'] += monthly_savings # Add potential savings
                 results['would_terminate'].append(inst_id) # Track potential action
                 logger.info(f"[{region}] Added {inst_id} ({inst_type}) to termination list. Est savings: ${monthly_savings:.2f}/mo.")

            # Perform Termination
            if results['would_terminate'] and not DRY_RUN:
                try:
                    ids_to_term = results['would_terminate']
                    logger.info(f"[{region}] Terminating {len(ids_to_term)} instances: {ids_to_term}")
                    ec2_client.terminate_instances(InstanceIds=ids_to_term)
                    results['terminated'].extend(ids_to_term) # Track actual action
                except ClientError as e:
                    results['errors'].append(f"EC2 Term Err: {e}")
                    # Don't subtract savings, it's a potential estimate

        except ClientError as e: results['errors'].append(f"EC2 Desc Err: {e}")

    # --- 2. Report non-optimized/low CPU instances ---
    if ENABLE_EC2_OPTIMIZATION_REPORTING:
        try:
            paginator = ec2_client.get_paginator("describe_instances")
            # Check running or stopped instances that weren't targeted for termination
            target_ids = set(results['would_terminate'])
            page_iterator = paginator.paginate(Filters=[{"Name": "instance-state-name", "Values": ["running", "stopped"]}])
            older_gen_types = ['t2','m1','m2','m3','m4','c1','c3','c4','r3','r4','i2','d2','g2','f1','x1','p2','h1']
            check_start_time = now_utc - timedelta(days=EC2_RIGHTSIZE_CHECK_DAYS)

            for page in page_iterator:
                for reservation in page["Reservations"]:
                    for instance in reservation["Instances"]:
                        instance_id, instance_type, tags = instance["InstanceId"], instance["InstanceType"], instance.get("Tags", [])
                        if instance_id in target_ids or is_excluded(tags): continue

                        # Check Older Generation Type
                        family = instance_type.split('.')[0]
                        if family in older_gen_types:
                            results['older_gen'].append(f"{instance_id}({instance_type})")

                        # Check Low CPU (only for running instances usually)
                        if instance.get('State', {}).get('Name') == 'running':
                            try:
                                metrics = cloudwatch_client.get_metric_statistics(
                                    Namespace='AWS/EC2', MetricName='CPUUtilization',
                                    Dimensions=[{'Name': 'InstanceId', 'Value': instance_id}],
                                    StartTime=check_start_time, EndTime=now_utc,
                                    Period=86400, Statistics=['Average'], Unit='Percent' # Daily average
                                )
                                avg_cpu_list = [dp['Average'] for dp in metrics['Datapoints']]
                                if avg_cpu_list:
                                    avg_cpu = mean(avg_cpu_list)
                                    if avg_cpu < EC2_LOW_CPU_THRESHOLD_PERCENT:
                                        results['low_cpu'].append(f"{instance_id}({instance_type}: {avg_cpu:.1f}% avg CPU)")
                                else:
                                    logger.debug(f"[{region}] No CPU metrics found for {instance_id} in period.")
                            except (ClientError, KeyError, ValueError, TypeError) as e:
                                logger.warning(f"[{region}] Failed to get CPU metrics for {instance_id}: {e}")
                                results['errors'].append(f"EC2 CPU Metric Err ({instance_id}): {e}")

        except ClientError as e: results['errors'].append(f"EC2 Type/CPU Check Err: {e}")

    logger.info(f"--- Finished EC2 Optimization in {region} ---")

    # --- Build Summary ---
    term_count = len(results['would_terminate']) if DRY_RUN else len(results['terminated'])
    if term_count > 0:
        action = "Would terminate" if DRY_RUN else "Terminated"
        ids = results['would_terminate'] if DRY_RUN else results['terminated']
        results['summary_lines'].append(f"{action} {term_count} stopped instance(s): {ids[:5]}...")
    else: results['summary_lines'].append("No stopped instances needed termination.")

    if results['older_gen']: results['summary_lines'].append(f"Found {len(results['older_gen'])} older gen instance(s): {results['older_gen'][:5]}...")
    else: results['summary_lines'].append("No instances found using common older gen types.")

    if results['low_cpu']: results['summary_lines'].append(f"Found {len(results['low_cpu'])} low CPU instance(s): {results['low_cpu'][:3]}...")
    else: results['summary_lines'].append("No instances flagged for low CPU.")

    if results['errors']: results['summary_lines'].append(f"Errors: {len(results['errors'])}")

    savings_label = "Estimated potential"
    final_savings = max(0, results['savings'])
    results['summary_lines'].append(f"{savings_label} savings: ${final_savings:.2f} USD/month by EC2")
    return " | ".join(results['summary_lines']), final_savings


def optimize_ebs(ec2_client, cloudwatch_client, region): 
    """Optimize EBS: Delete available, convert gp2->gp3, report idle, delete old snapshots."""
    logger.info(f"--- Starting EBS Optimization in {region} ---")
    now_utc = datetime.now(timezone.utc)
    results = { "savings": 0.0, "errors": [], "summary_lines": [],
                "would_delete_vol": [], "deleted_vol": [],
                "would_convert_vol": [], "converted_vol": [],
                "would_delete_snap": [], "deleted_snap": [],
                "idle_reported_vol": [] }

    gp2_p, gp3_p, snap_p = get_ebs_price('gp2', region), get_ebs_price('gp3', region), get_ebs_snapshot_price(region)

    # --- 1. Delete available volumes ---
    if ENABLE_EBS_AVAILABLE_VOLUME_DELETION:
        
        try:
            paginator = ec2_client.get_paginator("describe_volumes"); avail_vols = []
            for page in paginator.paginate(Filters=[{"Name": "status", "Values": ["available"]}]):
                for vol in page['Volumes']:
                    if not is_excluded(vol.get("Tags", [])): avail_vols.append({'id':vol['VolumeId'],'size':vol['Size'],'type':vol['VolumeType']})
            logger.info(f"[{region}] Found {len(avail_vols)} avail vols.")
            for v in avail_vols:
                vp = get_ebs_price(v['type'], region); vs = (v['size'] * vp) if vp else 0.0
                if vs > 0: results['savings'] += vs
                if DRY_RUN: logger.info(f"[DRY RUN] Would del vol {v['id']} ({v['type']}). Est ${vs:.2f}"); results['would_delete_vol'].append(v['id'])
                else:
                    try: logger.info(f"Deleting vol {v['id']}. Est ${vs:.2f}"); ec2_client.delete_volume(VolumeId=v['id']); results['deleted_vol'].append(v['id'])
                    except ClientError as e: results['errors'].append(f"VolDelErr({v['id']}):{e}"); results['savings'] -= vs
        except ClientError as e: results['errors'].append(f"DescAvailVolErr:{e}")


    # --- 2. Convert GP2 to GP3 ---
    processed_for_conversion = set(results['would_delete_vol']) if DRY_RUN else set(results['deleted_vol'])
    if ENABLE_EBS_GP2_TO_GP3_CONVERSION:
         # ... (Keep logic from previous version, update results dict) ...
        try:
            paginator=ec2_client.get_paginator("describe_volumes"); vols_to_conv=[]
            for page in paginator.paginate(Filters=[{'Name':'volume-type','Values':['gp2']}]):
                for vol in page['Volumes']:
                    vol_id=vol['VolumeId']
                    if vol_id in processed_for_conversion or is_excluded(vol.get("Tags",[])): continue
                    is_root = any(a.get('Device') in ['/dev/sda1','/dev/xvda'] for a in vol.get('Attachments',[]))
                    if is_root and not ENABLE_EBS_GP2_TO_GP3_CONVERSION_FOR_ROOT: continue
                    vols_to_conv.append({'id':vol_id, 'size':vol['Size']})
            logger.info(f"[{region}] Found {len(vols_to_conv)} gp2 vols for conversion.")
            if gp2_p and gp3_p and gp2_p > gp3_p:
                sav_gb = gp2_p - gp3_p
                for v in vols_to_conv:
                    vs = v['size']*sav_gb; results['savings']+=vs
                    if DRY_RUN: logger.info(f"[DRY RUN] Would conv gp2 {v['id']}. Est ${vs:.2f}"); results['would_convert_vol'].append(v['id'])
                    else:
                        try: logger.info(f"Converting gp2 {v['id']}. Est ${vs:.2f}"); ec2_client.modify_volume(VolumeId=v['id'],VolumeType='gp3'); results['converted_vol'].append(v['id'])
                        except ClientError as e: results['errors'].append(f"VolModErr({v['id']}):{e}"); results['savings']-=vs
            else: logger.warning(f"[{region}] Cannot calculate gp2->gp3 savings.")
        except ClientError as e: results['errors'].append(f"DescGp2VolErr:{e}")


    # --- 3. Report Idle Volumes (High Idle Time) ---
    if ENABLE_EBS_IDLE_VOLUME_REPORTING:
         try:
            logger.info(f"[{region}] Checking for idle EBS volumes (IdleTime > {EBS_IDLE_TIME_THRESHOLD_PERCENT}% over {EBS_IDLE_CHECK_DAYS} days)...")
            check_start_time = now_utc - timedelta(days=EBS_IDLE_CHECK_DAYS)
            paginator = ec2_client.get_paginator("describe_volumes")
            # Check 'in-use' volumes only
            page_iterator = paginator.paginate(Filters=[{"Name": "status", "Values": ["in-use"]}])

            for page in page_iterator:
                 for volume in page['Volumes']:
                     vol_id = volume['VolumeId']
                     tags = volume.get("Tags", [])
                     # Skip if excluded or already handled
                     if vol_id in processed_for_conversion or is_excluded(tags): continue

                     try:
                         metrics = cloudwatch_client.get_metric_statistics(
                             Namespace='AWS/EBS', MetricName='VolumeIdleTime',
                             Dimensions=[{'Name': 'VolumeId', 'Value': vol_id}],
                             StartTime=check_start_time, EndTime=now_utc,
                             Period=86400, Statistics=['Average'], Unit='Seconds'
                         )
                         # Idle time is reported as seconds per period (e.g., 0-300 for 5min period).
                         # To get percentage idle, compare average seconds idle to period length.
                         # AWS reports 0 if completely busy, 300 if completely idle (for 5 min period).
                         
                         avg_idle_seconds_list = [dp['Average'] for dp in metrics['Datapoints']]
                         if avg_idle_seconds_list:
                              # Average idle seconds per day
                              avg_idle_daily = mean(avg_idle_seconds_list)
                              # Percentage idle within a day
                              percent_idle = (avg_idle_daily / 86400) * 100 if avg_idle_daily is not None else 0
                              if percent_idle > EBS_IDLE_TIME_THRESHOLD_PERCENT:
                                   results['idle_reported_vol'].append(f"{vol_id} ({percent_idle:.1f}% idle)")
                         else:
                              logger.debug(f"[{region}] No VolumeIdleTime metrics found for {vol_id}.")

                     except (ClientError, KeyError, ValueError, TypeError) as e:
                         logger.warning(f"[{region}] Failed get IdleTime metrics for {vol_id}: {e}")
                         results['errors'].append(f"EBS Idle Metric Err ({vol_id}): {e}")

         except ClientError as e: results['errors'].append(f"EBS Desc InUse Err: {e}")


    # --- 4. Delete old snapshots ---
    if ENABLE_EBS_SNAPSHOT_DELETION:
         
        try:
            # !!! WARNING: Using minutes for testing. Change to days for production. !!!
            cutoff = now_utc - timedelta(minutes=EBS_SNAPSHOT_RETENTION_DAYS)
            logger.info(f"[{region}] Checking snapshots older than {cutoff.isoformat()} ({EBS_SNAPSHOT_RETENTION_DAYS} mins)")
            paginator = ec2_client.get_paginator("describe_snapshots"); snaps_to_del=[]
            for page in paginator.paginate(OwnerIds=["self"]):
                for snap in page['Snapshots']:
                    desc = snap.get('Description','').lower()
                    if 'createimage' in desc or 'aws backup' in desc or 'dlm lifecycle' in desc: continue
                    snap_id = snap['SnapshotId']
                    if is_excluded(snap.get("Tags",[])): continue
                    if snap['StartTime'] < cutoff: snaps_to_del.append({'id':snap_id,'size':snap['VolumeSize'],'time':snap['StartTime']})
            logger.info(f"[{region}] Found {len(snaps_to_del)} old snaps.")
            if snap_p:
                for s in snaps_to_del:
                    ss = s['size']*snap_p; results['savings']+=ss
                    if DRY_RUN: logger.info(f"[DRY RUN] Would del snap {s['id']}. Est ${ss:.2f}"); results['would_delete_snap'].append(s['id'])
                    else:
                        try: logger.info(f"Deleting snap {s['id']}. Est ${ss:.2f}"); ec2_client.delete_snapshot(SnapshotId=s['id']); results['deleted_snap'].append(s['id'])
                        except ClientError as e: results['errors'].append(f"SnapDelErr({s['id']}):{e}"); results['savings']-=ss
            else: logger.warning(f"[{region}] Cannot calc snap savings (price unavailable).")
        except ClientError as e: results['errors'].append(f"DescSnapErr:{e}")


    logger.info(f"--- Finished EBS Optimization in {region} ---")

    # --- Build Summary ---
    vdc=len(results['would_delete_vol']) if DRY_RUN else len(results['deleted_vol'])
    vcc=len(results['would_convert_vol']) if DRY_RUN else len(results['converted_vol'])
    sdc=len(results['would_delete_snap']) if DRY_RUN else len(results['deleted_snap'])

    if vdc>0: results['summary_lines'].append(f"{'Would del' if DRY_RUN else 'Deleted'} {vdc} avail vol(s): { (results['would_delete_vol'] if DRY_RUN else results['deleted_vol'])[:5]}...")
    else: results['summary_lines'].append("No avail vols deleted.")
    if vcc>0: results['summary_lines'].append(f"{'Would conv' if DRY_RUN else 'Converted'} {vcc} vol(s) gp2->gp3: { (results['would_convert_vol'] if DRY_RUN else results['converted_vol'])[:5]}...")
    else: results['summary_lines'].append("No vols converted.")
    if results['idle_reported_vol']: results['summary_lines'].append(f"Found {len(results['idle_reported_vol'])} potentially idle volume(s): {results['idle_reported_vol'][:5]}...")
    else: results['summary_lines'].append("No idle volumes reported.")
    if sdc>0: results['summary_lines'].append(f"{'Would del' if DRY_RUN else 'Deleted'} {sdc} old snapshot(s): { (results['would_delete_snap'] if DRY_RUN else results['deleted_snap'])[:5]}...")
    else: results['summary_lines'].append("No old snaps deleted.")

    if results['errors']: results['summary_lines'].append(f"Errors: {len(results['errors'])}")
    final_savings = max(0, results['savings'])
    results['summary_lines'].append(f"{'Est potential' if DRY_RUN else 'Achieved'} savings: ${final_savings:.2f} USD/month by EBS")
    return " | ".join(results['summary_lines']), final_savings


def optimize_load_balancers(elbv2_client, cloudwatch_client, region):
    logger.info(f"--- Starting Load Balancer Optimization in {region} ---")
    if not ENABLE_ELB_DELETION: return "Load Balancer deletion is disabled.", 0
    now_utc = datetime.now(timezone.utc)
    cutoff = now_utc - timedelta(minutes=ELB_IDLE_DAYS_THRESHOLD) # Mins for testing
    logger.info(f"[{region}] Checking LBs idle since {cutoff.isoformat()} ({ELB_IDLE_DAYS_THRESHOLD} mins)")
    lbs_to_del = []; errors = []; elb_savings = 0.0; del_names = []
    try:
        paginator = elbv2_client.get_paginator('describe_load_balancers')
        for page in paginator.paginate():
            for lb in page['LoadBalancers']:
                arn, name, type, state = lb['LoadBalancerArn'], lb['LoadBalancerName'], lb['Type'], lb.get('State',{}).get('Code')
                if state != 'active': continue
                try:
                    tags = elbv2_client.describe_tags(ResourceArns=[arn])['TagDescriptions'][0].get('Tags',[])
                    if is_excluded(tags) or type == 'gateway': continue
                    metric = 'RequestCount' if type == 'application' else 'ActiveFlowCount'
                    ns = 'AWS/ApplicationELB' if type == 'application' else 'AWS/NetworkELB'
                    period = max(60, 3600 if (ELB_IDLE_DAYS_THRESHOLD*60)>=3600 else 300)
                    metrics = cloudwatch_client.get_metric_statistics( Namespace=ns, MetricName=metric, Dimensions=[{'Name':'LoadBalancer','Value':'/'.join(arn.split(':')[-1].split('/')[-3:])}], StartTime=cutoff, EndTime=now_utc, Period=period, Statistics=['Sum'], Unit='Count')
                    count = sum(dp['Sum'] for dp in metrics['Datapoints'])
                    tgs = elbv2_client.describe_target_groups(LoadBalancerArn=arn)['TargetGroups']
                    unhealthy = not tgs or all( not thd or all(t['TargetHealth']['State'] not in ['healthy','initial','draining'] for t in thd) for tg in tgs if (thd := elbv2_client.describe_target_health(TargetGroupArn=tg['TargetGroupArn'])['TargetHealthDescriptions']) is not None)
                    if count < 1 and unhealthy:
                        logger.info(f"[{region}] Found idle {type} LB {name}.")
                        lbs_to_del.append({'Arn':arn,'Name':name,'Type':type})
                        price = get_elb_price(type, region)
                        if price: elb_savings += price * 24 * 30.44
                except ClientError as e: errors.append(f"LB Proc Err ({name}):{e}")
                except Exception as e: errors.append(f"LB Unexp Err ({name}):{e}"); logger.error("LB Unexp Err",exc_info=True)
    except ClientError as e: errors.append(f"Desc LBs Err:{e}")
    if lbs_to_del:
        logger.info(f"[{region}] Processing {len(lbs_to_del)} LBs for deletion.")
        for lb in lbs_to_del:
            arn, name, type = lb['Arn'], lb['Name'], lb['Type']
            price = get_elb_price(type, region); savings = (price*24*30.44) if price else 0.0
            if DRY_RUN: logger.info(f"[DRY RUN] Would del {type} LB {name}. Est ${savings:.2f}")
            else:
                try: logger.info(f"Deleting {type} LB {name}. Est ${savings:.2f}"); elbv2_client.delete_load_balancer(LoadBalancerArn=arn); del_names.append(name)
                except ClientError as e: errors.append(f"LB Del Err ({name}):{e}"); elb_savings -= savings
    logger.info(f"--- Finished Load Balancer Optimization in {region} ---")
    summary_lines=[]
    count = len(lbs_to_del) if DRY_RUN else len(del_names)
    if count > 0: names = [lb['Name'] for lb in lbs_to_del] if DRY_RUN else del_names; summary_lines.append(f"{'Would delete' if DRY_RUN else 'Deleted'} {count} idle LB(s): {names[:5]}...")
    else: summary_lines.append("No idle LBs found.")
    if errors: summary_lines.append(f"Errors: {len(errors)}")
    final_savings = max(0, elb_savings)
    summary_lines.append(f"{'Est potential' if DRY_RUN else 'Achieved'} savings: ${final_savings:.2f} USD/month by ELB")
    return " | ".join(summary_lines), final_savings

def optimize_elastic_ips(ec2_client, region):
    logger.info(f"--- Starting Elastic IP Optimization in {region} ---")
    if not ENABLE_EIP_RELEASE: return "EIP release disabled.", 0
    to_release=[]; released=[]; skipped=[]; errors=[]; eip_savings=0.0
    monthly_cost = UNATTACHED_EIP_PRICE_HOURLY * 24 * 30.44
    try:
        for addr in ec2_client.describe_addresses().get("Addresses",[]):
            alloc_id, ip, tags = addr.get("AllocationId"), addr.get("PublicIp"), addr.get("Tags",[])
            if "AssociationId" in addr: continue
            if is_excluded(tags): skipped.append(ip); continue
            logger.info(f"[{region}] Found unattached EIP: {ip} ({alloc_id}).")
            to_release.append(alloc_id); eip_savings += monthly_cost
        if to_release:
            logger.info(f"[{region}] Processing {len(to_release)} EIPs.")
            for alloc_id in to_release:
                if DRY_RUN: logger.info(f"[DRY RUN] Would release EIP {alloc_id}. Est ${monthly_cost:.2f}")
                else:
                    try: logger.info(f"Releasing EIP {alloc_id}. Est ${monthly_cost:.2f}"); ec2_client.release_address(AllocationId=alloc_id); released.append(alloc_id)
                    except ClientError as e: errors.append(f"EIP Rel Err ({alloc_id}):{e}"); eip_savings -= monthly_cost
        else: logger.info(f"[{region}] No unattached EIPs found.")
    except ClientError as e: errors.append(f"DescAddr Err:{e}")
    logger.info(f"--- Finished Elastic IP Optimization in {region} ---")
    summary_lines=[]; count=len(to_release) if DRY_RUN else len(released)
    if count>0: ids = to_release if DRY_RUN else released; summary_lines.append(f"{'Would release' if DRY_RUN else 'Released'} {count} EIP(s): {ids[:5]}...")
    else: summary_lines.append("No unattached EIPs found.")
    if skipped: summary_lines.append(f"Skipped {len(skipped)} excluded EIP(s).")
    if errors: summary_lines.append(f"Errors: {len(errors)}")
    final_savings = max(0, eip_savings)
    summary_lines.append(f"{'Est potential' if DRY_RUN else 'Achieved'} savings: ${final_savings:.2f} USD/month by EIPs")
    return " | ".join(summary_lines), final_savings

def optimize_cloudwatch_logs(logs_client, region):
    logger.info(f"--- Starting CloudWatch Log Group Optimization in {region} ---")
    if not ENABLE_CW_LOG_GROUP_RETENTION_MANAGEMENT: return "CW Log Group retention disabled.", 0
    would_mod=[]; modified_count=0; skipped=[]; errors=[]
    try:
        paginator=logs_client.get_paginator('describe_log_groups')
        for page in paginator.paginate():
            for lg in page.get('logGroups',[]):
                name, current_ret = lg['logGroupName'], lg.get('retentionInDays')
                tags = {}
                try: tags = logs_client.list_tags_log_group(logGroupName=name).get('tags',{})
                except ClientError: pass # Ignore tag errors for now
                if is_excluded(tags): skipped.append(name); continue
                env = tags.get(ENVIRONMENT_TAG_KEY,'').lower()
                target = CW_LOG_GROUP_RETENTION_DEFAULT_DAYS
                if env in ENV_VALUES_PROD or env in ENV_VALUES_UAT: target = CW_LOG_GROUP_RETENTION_PROD_UAT_DAYS
                elif env in ENV_VALUES_DEV: target = CW_LOG_GROUP_RETENTION_DEV_DAYS
                if current_ret is None or current_ret > target:
                    orig = "'Never'" if current_ret is None else f"{current_ret}d"
                    if DRY_RUN: logger.info(f"[DRY RUN] Would set {name} ret {orig}->{target}d."); would_mod.append(name)
                    else:
                        try: logger.info(f"Setting {name} ret {orig}->{target}d."); logs_client.put_retention_policy(logGroupName=name, retentionInDays=target); modified_count+=1
                        except ClientError as e: errors.append(f"SetRetErr({name}):{e}")
        count = len(would_mod) if DRY_RUN else modified_count
        if count>0: logger.info(f"[{region}] {'Would modify' if DRY_RUN else 'Modified'} ret for {count} LG(s).")
        else: logger.info(f"[{region}] No LGs required ret updates.")
    except ClientError as e: errors.append(f"DescLGErr:{e}")
    logger.info(f"--- Finished CloudWatch Log Group Optimization in {region} ---")
    summary_lines=[]; count_sum = len(would_mod) if DRY_RUN else modified_count
    if count_sum>0: summary_lines.append(f"{'Would modify' if DRY_RUN else 'Modified'} retention for {count_sum} LG(s).")
    else: summary_lines.append("No LGs needed retention updates.")
    if skipped: summary_lines.append(f"Skipped {len(skipped)} excluded LG(s).")
    if errors: summary_lines.append(f"Errors: {len(errors)}")
    summary_lines.append("$0.00 USD per month estimated savings by CW Logs") # Report $0
    return " | ".join(summary_lines), 0.0

def report_cloudwatch_alarms(cloudwatch_client, region):
    logger.info(f"--- Starting CloudWatch Alarm Reporting in {region} ---")
    if not ENABLE_CW_INSUFFICIENT_DATA_ALARM_REPORTING: return "CW Alarm reporting disabled."
    now_utc = datetime.now(timezone.utc)
    cutoff = now_utc - timedelta(minutes=CW_ALARM_INSUFFICIENT_DATA_DAYS_THRESHOLD) # Mins for testing
    logger.info(f"[{region}] Checking alarms INSUFFICIENT_DATA since {cutoff.isoformat()} ({CW_ALARM_INSUFFICIENT_DATA_DAYS_THRESHOLD} mins)")
    to_report=[]; errors=[]
    try:
        paginator=cloudwatch_client.get_paginator('describe_alarms')
        for page in paginator.paginate():
            for alarm in page.get('MetricAlarms',[]) + page.get('CompositeAlarms',[]):
                if alarm.get('StateValue') != 'INSUFFICIENT_DATA' or not alarm.get('StateUpdatedTimestamp'): continue
                tags=[]
                try: tags = cloudwatch_client.list_tags_for_resource(ResourceARN=alarm['AlarmArn']).get('Tags',[])
                except ClientError: pass
                if is_excluded(tags): continue
                if alarm['StateUpdatedTimestamp'] < cutoff: to_report.append(alarm['AlarmName'])
        if to_report:
            logger.warning(f"[{region}] {len(to_report)} Alarms INSUFFICIENT_DATA > {CW_ALARM_INSUFFICIENT_DATA_DAYS_THRESHOLD} mins:")
            for name in to_report: logger.warning(f"  - {name}")
            logger.warning(f"[{region}] Review removal from IaC source recommended.")
        else: logger.info(f"[{region}] No long-standing INSUFFICIENT_DATA alarms.")
    except ClientError as e: errors.append(f"DescAlarmsErr:{e}")
    logger.info(f"--- Finished CloudWatch Alarm Reporting in {region} ---")
    summary_lines=[]
    if to_report: summary_lines.append(f"Found {len(to_report)} long-standing INSUFFICIENT_DATA alarm(s).")
    else: summary_lines.append("No long-standing INSUFFICIENT_DATA alarms.")
    if errors: summary_lines.append(f"Errors: {len(errors)}")
    return " | ".join(summary_lines)

def optimize_s3(s3_client, region):
    logger.info(f"--- Starting S3 Optimization in {region} ---")
    if not ENABLE_S3_OBJECT_DELETION: return "S3 object deletion disabled.", 0
    now_utc = datetime.now(timezone.utc)
    cutoff = now_utc - timedelta(minutes=S3_OBJECT_AGE_DAYS_THRESHOLD) # Mins for testing
    logger.info(f"[{region}] Checking objects older than {cutoff.isoformat()} ({S3_OBJECT_AGE_DAYS_THRESHOLD} mins)")
    buckets_proc=0; obj_ident=0; obj_del=0; s3_savings=0.0; errors=[]
    try:
        for bucket in s3_client.list_buckets().get('Buckets',[]):
            bname=bucket['Name']
            try:
                loc=s3_client.get_bucket_location(Bucket=bname).get('LocationConstraint')
                if (loc if loc else 'us-east-1')!=region: continue
                tags=s3_client.get_bucket_tagging(Bucket=bname).get('TagSet',[])
                if get_tag_value(tags, S3_CLEANUP_TAG_KEY)!=S3_CLEANUP_TAG_VALUE or is_excluded(tags): continue
            except ClientError as e:
                if e.response['Error']['Code']!='NoSuchTagSet': logger.warning(f"[{region}] S3 Prelim Fail ({bname}): {e}")
                continue
            logger.info(f"[{region}] Processing tagged bucket {bname}...")
            buckets_proc+=1; bucket_obj_del=0
            try:
                vers=s3_client.get_bucket_versioning(Bucket=bname).get('Status')
                if vers=='Enabled': logger.warning(f"[{region}] Skipping versioned bucket {bname}."); continue
                paginator=s3_client.get_paginator('list_objects_v2'); batch=[]; batch_bytes=0
                for page in paginator.paginate(Bucket=bname):
                    for obj in page.get('Contents',[]):
                        if obj['LastModified'] < cutoff and not (obj['Key'].endswith('/') and obj.get('Size',0)==0):
                            batch.append({'Key':obj['Key']}); batch_bytes+=obj.get('Size',0); obj_ident+=1
                            if len(batch)>=1000:
                                sv=(batch_bytes/(1024**3))*S3_STANDARD_PRICE_GB_MONTH; s3_savings+=sv
                                if DRY_RUN: logger.info(f"[DRY RUN] Would del {len(batch)} batch from {bname}. Est ${sv:.2f}")
                                else:
                                    try: logger.info(f"Deleting {len(batch)} batch. Est ${sv:.2f}"); s3_client.delete_objects(Bucket=bname,Delete={'Objects':batch,'Quiet':True}); bucket_obj_del+=len(batch)
                                    except ClientError as e: errors.append(f"S3BatchDelErr({bname}):{e}"); s3_savings-=sv
                                batch,batch_bytes=[],0
                if batch:
                    sv=(batch_bytes/(1024**3))*S3_STANDARD_PRICE_GB_MONTH; s3_savings+=sv
                    if DRY_RUN: logger.info(f"[DRY RUN] Would del {len(batch)} final batch from {bname}. Est ${sv:.2f}")
                    else:
                        try: logger.info(f"Deleting {len(batch)} final batch. Est ${sv:.2f}"); s3_client.delete_objects(Bucket=bname,Delete={'Objects':batch,'Quiet':True}); bucket_obj_del+=len(batch)
                        except ClientError as e: errors.append(f"S3FinalDelErr({bname}):{e}"); s3_savings-=sv
            except ClientError as e: errors.append(f"S3 List/Vers Err ({bname}):{e}")
            obj_del+=bucket_obj_del
        final_cnt=obj_ident if DRY_RUN else obj_del
        if buckets_proc>0: logger.info(f"[{region}] S3: Processed {buckets_proc} buckets. {'Would del' if DRY_RUN else 'Deleted'} {final_cnt} objects.")
        else: logger.info(f"[{region}] S3: No tagged buckets found.")
    except ClientError as e: errors.append(f"S3 ListBuckets Err:{e}")
    logger.info(f"--- Finished S3 Optimization in {region} ---")
    summary_lines=[]; sl='Est potential' if DRY_RUN else 'Achieved'; final_cnt_sum=obj_ident if DRY_RUN else obj_del
    if buckets_proc>0:
        summary_lines.append(f"Processed {buckets_proc} bucket(s).")
        if final_cnt_sum>0: summary_lines.append(f"{'Would delete' if DRY_RUN else 'Deleted'} {final_cnt_sum} object(s).")
        else: summary_lines.append("No objects met age criteria.")
    else: summary_lines.append("No tagged buckets found.")
    if errors: summary_lines.append(f"Errors: {len(errors)}")
    final_s3_savings=max(0,s3_savings)
    summary_lines.append(f"{sl} savings: ${final_s3_savings:.2f} USD/month by S3")
    return " | ".join(summary_lines), final_s3_savings


# --- NEW Optimization Functions ---

def optimize_lambda_functions(lambda_client, cloudwatch_client, region):
    """Report on potentially idle Lambda functions."""
    logger.info(f"--- Starting Lambda Function Idle Reporting in {region} ---")
    if not ENABLE_LAMBDA_IDLE_REPORTING: return "Lambda idle reporting disabled.", 0.0

    now_utc = datetime.now(timezone.utc)
    # Use DAYS for Lambda idle check, not minutes from test variables
    idle_start_time = now_utc - timedelta(days=LAMBDA_IDLE_DAYS_THRESHOLD)
    logger.info(f"[{region}] Checking Lambda functions for invocations since {idle_start_time.isoformat()} ({LAMBDA_IDLE_DAYS_THRESHOLD} days ago)")

    idle_functions = []
    errors = []
    lambda_savings = 0.0 # Reporting $0 savings, just identifying idle functions

    try:
        paginator = lambda_client.get_paginator('list_functions')
        for page in paginator.paginate():
            for function in page.get('Functions', []):
                func_name = function['FunctionName']
                func_arn = function['FunctionArn']
                last_modified_str = function['LastModified'] # Format: 2023-10-27T10:30:00.123+0000
                last_modified_dt = datetime.strptime(last_modified_str, '%Y-%m-%dT%H:%M:%S.%f%z')

                # Skip functions modified recently? Optional, prevents flagging new functions.
                if last_modified_dt > idle_start_time:
                    logger.debug(f"[{region}] Skipping recently modified Lambda {func_name} (modified {last_modified_dt}).")
                    continue

                # Check tags for exclusion
                try:
                    tags_response = lambda_client.list_tags(Resource=func_arn)
                    tags = tags_response.get('Tags', {}) # Lambda tags are dict
                    if is_excluded(tags):
                        logger.info(f"[{region}] Skipping excluded Lambda {func_name}.")
                        continue
                except ClientError as e:
                    logger.warning(f"[{region}] Could not get tags for Lambda {func_name}: {e}. Proceeding without exclusion check.")

                # Get invocation metrics from CloudWatch
                try:
                    # Period: duration of the check in seconds, min 60. Max 1440 data points.
                    period_seconds = max(60, int(timedelta(days=LAMBDA_IDLE_DAYS_THRESHOLD).total_seconds()))
                    # Adjust period if needed (e.g., if threshold > 1440 days)
                    # For typical 30-90 days, one data point for the whole period is fine.
                    period_seconds = min(period_seconds, 86400 * 30) # Example: Cap period for CW query if needed


                    metrics = cloudwatch_client.get_metric_statistics(
                        Namespace='AWS/Lambda',
                        MetricName='Invocations',
                        Dimensions=[{'Name': 'FunctionName', 'Value': func_name}],
                        StartTime=idle_start_time,
                        EndTime=now_utc,
                        Period=period_seconds,
                        Statistics=['Sum'],
                        Unit='Count'
                    )
                    total_invocations = sum(dp['Sum'] for dp in metrics['Datapoints'])

                    if total_invocations <= LAMBDA_IDLE_INVOCATION_THRESHOLD:
                        logger.info(f"[{region}] Found potentially idle Lambda {func_name} ({total_invocations} invocations in last {LAMBDA_IDLE_DAYS_THRESHOLD} days).")
                        idle_functions.append(func_name)
                    else:
                         logger.debug(f"[{region}] Lambda {func_name} seems active ({total_invocations} invocations).")

                except ClientError as e:
                    # Might fail if function never invoked / metrics don't exist
                    if e.response['Error']['Code'] == 'InvalidParameterValue':
                         logger.debug(f"[{region}] No invocation metrics found for Lambda {func_name} in period. Assuming idle.")
                         # Check if function was created *before* the idle_start_time to be sure
                         if last_modified_dt < idle_start_time:
                              logger.info(f"[{region}] Found potentially idle Lambda {func_name} (no invocations found in last {LAMBDA_IDLE_DAYS_THRESHOLD} days).")
                              idle_functions.append(func_name)
                         else:
                              logger.debug(f"[{region}] Lambda {func_name} created recently, skipping idle check based on missing metrics.")
                    else:
                         logger.error(f"[{region}] Error getting CloudWatch metrics for Lambda {func_name}: {e}")
                         errors.append(f"Lambda CW Err ({func_name}): {str(e)}")
                except Exception as e:
                     logger.error(f"[{region}] Unexpected error processing Lambda {func_name} metrics: {e}")
                     errors.append(f"Lambda Proc Err ({func_name}): {str(e)}")

    except ClientError as e:
        logger.error(f"[{region}] Error listing Lambda functions: {e}")
        errors.append(f"List Functions Err: {str(e)}")

    logger.info(f"--- Finished Lambda Function Idle Reporting in {region} ---")

    # --- Return Summary ---
    summary_lines = []
    if idle_functions:
        summary_lines.append(f"Found {len(idle_functions)} potentially idle Lambda function(s) (<= {LAMBDA_IDLE_INVOCATION_THRESHOLD} invocations/{LAMBDA_IDLE_DAYS_THRESHOLD} days): {idle_functions[:5]}...")
    else:
        summary_lines.append("No potentially idle Lambda functions found.")
    if errors:
        summary_lines.append(f"Encountered {len(errors)} error(s): {errors[:3]}...")

    # Return $0 savings, as it's reporting only
    return " | ".join(summary_lines), 0.0


def optimize_eks_clusters(eks_client, region):
    """Report on potentially unused EKS clusters (basic check)."""
    logger.info(f"--- Starting EKS Cluster Unused Reporting in {region} ---")
    if not ENABLE_EKS_UNUSED_CLUSTER_REPORTING: return "EKS unused reporting disabled.", 0.0

    unused_clusters = []
    errors = []
    eks_savings = 0.0
    eks_monthly_cost = EKS_CONTROL_PLANE_PRICE_HOURLY * 24 * 30.44

    try:
        paginator = eks_client.get_paginator('list_clusters')
        for page in paginator.paginate():
            for cluster_name in page.get('clusters', []):
                logger.debug(f"[{region}] Checking EKS cluster: {cluster_name}")
                try:
                    cluster_info = eks_client.describe_cluster(name=cluster_name)['cluster']
                    cluster_status = cluster_info.get('status')
                    cluster_arn = cluster_info.get('arn')
                    tags = cluster_info.get('tags', {}) # EKS tags are dict

                    if cluster_status != 'ACTIVE':
                        logger.debug(f"[{region}] Skipping EKS cluster {cluster_name} (status: {cluster_status}).")
                        continue

                    if is_excluded(tags):
                        logger.info(f"[{region}] Skipping excluded EKS cluster {cluster_name}.")
                        continue

                    # Check for associated nodegroups
                    nodegroups_response = eks_client.list_nodegroups(clusterName=cluster_name)
                    has_nodegroups = bool(nodegroups_response.get('nodegroups'))

                    # Check for associated Fargate profiles
                    fargate_response = eks_client.list_fargate_profiles(clusterName=cluster_name)
                    has_fargate_profiles = bool(fargate_response.get('fargateProfileNames'))

                    # Basic Heuristic: ACTIVE, no managed nodegroups, no fargate profiles
                    if not has_nodegroups and not has_fargate_profiles:
                        logger.warning(f"[{region}] Found potentially unused EKS cluster {cluster_name} (ACTIVE, but no managed nodegroups or Fargate profiles found). Manual verification needed.")
                        unused_clusters.append(cluster_name)
                        eks_savings += eks_monthly_cost # Add potential savings
                    else:
                        logger.debug(f"[{region}] EKS cluster {cluster_name} appears active (has nodegroups: {has_nodegroups}, has Fargate: {has_fargate_profiles}).")

                except ClientError as e:
                    logger.error(f"[{region}] Error describing or checking EKS cluster {cluster_name}: {e}")
                    errors.append(f"EKS Check Err ({cluster_name}): {str(e)}")
                except Exception as e:
                    logger.error(f"[{region}] Unexpected error processing EKS cluster {cluster_name}: {e}", exc_info=True)
                    errors.append(f"EKS Proc Err ({cluster_name}): {str(e)}")

    except ClientError as e:
        logger.error(f"[{region}] Error listing EKS clusters: {e}")
        errors.append(f"List EKS Err: {str(e)}")

    logger.info(f"--- Finished EKS Cluster Unused Reporting in {region} ---")

    # --- Return Summary ---
    summary_lines = []
    if unused_clusters:
        summary_lines.append(f"Found {len(unused_clusters)} potentially unused EKS cluster(s) (ACTIVE, no managed nodes/Fargate): {unused_clusters[:5]}...")
        summary_lines.append("WARNING: Verify manually before deletion!")
    else:
        summary_lines.append("No potentially unused EKS clusters found based on basic check.")
    if errors:
        summary_lines.append(f"Encountered {len(errors)} error(s): {errors[:3]}...")

    # Return potential savings from control plane cost
    final_eks_savings = max(0, eks_savings)
    savings_label = "Estimated potential" # Always potential for reporting unused
    summary_lines.append(f"{savings_label} savings: ${final_eks_savings:.2f} USD/month by EKS")
    return " | ".join(summary_lines), final_eks_savings

def optimize_rds(rds_client, cloudwatch_client, region): # Added cloudwatch_client
    """Optimize RDS: retention, snapshots, report low CPU."""
    logger.info(f"--- Starting RDS Optimization in {region} ---")
    now_utc = datetime.now(timezone.utc)
    results = { "savings": 0.0, "errors": [], "summary_lines": [],
                "would_modify_inst_ret": [], "modified_inst_ret": 0,
                "would_modify_clus_ret": set(), "modified_clus_ret": 0,
                "would_delete_inst_snap": [], "deleted_inst_snap": [],
                "would_delete_clus_snap": [], "deleted_clus_snap": [],
                "low_cpu_reported_inst": [] }
    processed_clusters = set()

    # --- 1. Adjust Retention & Report Low CPU ---
    if ENABLE_RDS_BACKUP_RETENTION_ADJUSTMENT or ENABLE_RDS_LOW_CPU_REPORTING:
        logger.info(f"[{region}] Checking RDS instances/clusters...")
        try:
            paginator = rds_client.get_paginator('describe_db_instances')
            check_start_time = now_utc - timedelta(days=RDS_RIGHTSIZE_CHECK_DAYS) # For CPU check

            for page in paginator.paginate():
                for instance in page.get('DBInstances', []):
                    inst_id, inst_arn = instance['DBInstanceIdentifier'], instance['DBInstanceArn']
                    clus_id = instance.get('DBClusterIdentifier')
                    tags = []
                    try: # Get instance tags
                        tags = rds_client.list_tags_for_resource(ResourceName=inst_arn).get('TagList', [])
                    except ClientError: pass # Ignore tag errors for reporting if needed

                    if is_excluded(tags): continue # Skip excluded instances early

                    # -- Cluster Processing --
                    if clus_id:
                        if clus_id in processed_clusters: continue
                        processed_clusters.add(clus_id)
                        try:
                            clus_dets = rds_client.describe_db_clusters(DBClusterIdentifier=clus_id)['DBClusters'][0]
                            clus_arn = clus_dets['DBClusterArn']
                            clus_tags = rds_client.list_tags_for_resource(ResourceName=clus_arn).get('TagList', [])
                            if is_excluded(clus_tags): logger.info(f"Skipping excluded clus {clus_id}"); continue

                            # Retention Check
                            if ENABLE_RDS_BACKUP_RETENTION_ADJUSTMENT:
                                cur_ret = clus_dets['BackupRetentionPeriod']
                                if cur_ret > RDS_MAX_BACKUP_RETENTION_DAYS:
                                    if DRY_RUN: logger.info(f"[DRY] Would mod clus {clus_id} ret {cur_ret}->{RDS_MAX_BACKUP_RETENTION_DAYS}d"); results['would_modify_clus_ret'].add(clus_id)
                                    else:
                                        try: rds_client.modify_db_cluster(DBClusterIdentifier=clus_id, BackupRetentionPeriod=RDS_MAX_BACKUP_RETENTION_DAYS); results['modified_clus_ret']+=1; logger.info(f"Mod clus {clus_id} ret.")
                                        except ClientError as e: results['errors'].append(f"ClusModErr({clus_id}):{e}")
                            # Note: CPU check often better on instance level for clusters

                        except (ClientError, IndexError) as e: results['errors'].append(f"ClusFetchErr({clus_id}):{e}")

                    # -- Standalone Instance Processing --
                    else:
                        # Retention Check
                        current_retention = instance.get('BackupRetentionPeriod')
                        if ENABLE_RDS_BACKUP_RETENTION_ADJUSTMENT and current_retention is not None and current_retention > RDS_MAX_BACKUP_RETENTION_DAYS:
                            if DRY_RUN: logger.info(f"[DRY] Would mod inst {inst_id} ret {current_retention}->{RDS_MAX_BACKUP_RETENTION_DAYS}d"); results['would_modify_inst_ret'].append(inst_id)
                            else:
                                try: rds_client.modify_db_instance(DBInstanceIdentifier=inst_id,BackupRetentionPeriod=RDS_MAX_BACKUP_RETENTION_DAYS,ApplyImmediately=False); results['modified_inst_ret']+=1; logger.info(f"Mod inst {inst_id} ret.")
                                except ClientError as e: results['errors'].append(f"InstModErr({inst_id}):{e}")

                        # Low CPU Check (for running instances)
                        if ENABLE_RDS_LOW_CPU_REPORTING and instance.get('DBInstanceStatus') == 'available':
                             try:
                                 metrics = cloudwatch_client.get_metric_statistics(
                                     Namespace='AWS/RDS', MetricName='CPUUtilization',
                                     Dimensions=[{'Name': 'DBInstanceIdentifier', 'Value': inst_id}],
                                     StartTime=check_start_time, EndTime=now_utc,
                                     Period=86400, Statistics=['Average'], Unit='Percent' )
                                 avg_cpu_list = [dp['Average'] for dp in metrics['Datapoints']]
                                 if avg_cpu_list:
                                     avg_cpu = mean(avg_cpu_list)
                                     if avg_cpu < RDS_LOW_CPU_THRESHOLD_PERCENT:
                                         results['low_cpu_reported_inst'].append(f"{inst_id} ({avg_cpu:.1f}% avg CPU)")
                                 else: logger.debug(f"[{region}] No RDS CPU metrics found for {inst_id}.")
                             except (ClientError, KeyError, ValueError, TypeError) as e:
                                 logger.warning(f"[{region}] Failed get RDS CPU metrics for {inst_id}: {e}")
                                 results['errors'].append(f"RDS CPU Metric Err ({inst_id}): {e}")

        except ClientError as e: results['errors'].append(f"DescInstErr:{e}")

    # --- 2 & 3. Snapshot Deletion ---
    if ENABLE_RDS_MANUAL_SNAPSHOT_DELETION:
        # (Keep existing logic from previous version, update results dict)
        cutoff = now_utc - timedelta(minutes=RDS_MANUAL_SNAPSHOT_RETENTION_DAYS) # Mins for testing
        try: # Instance Snaps
            logger.info(f"[{region}] Checking inst snaps older than {cutoff.isoformat()} ({RDS_MANUAL_SNAPSHOT_RETENTION_DAYS} mins)")
            paginator=rds_client.get_paginator('describe_db_snapshots')
            for page in paginator.paginate(SnapshotType='manual',IncludeShared=False):
                for snap in page.get('DBSnapshots',[]):
                    sid,arn,stime=snap['DBSnapshotIdentifier'],snap['DBSnapshotArn'],snap.get('SnapshotCreateTime')
                    try: tags=rds_client.list_tags_for_resource(ResourceName=arn).get('TagList',[]);
                    except ClientError: tags=[] # Ignore tag errors for deletion check
                    if is_excluded(tags): continue
                    if snap.get('Status')=='available' and stime and stime < cutoff:
                        sz=snap.get('AllocatedStorage',0); sv=sz*RDS_SNAPSHOT_PRICE_GB_MONTH; results['savings']+=sv
                        if DRY_RUN: logger.info(f"[DRY] Would del inst snap {sid}. Est ${sv:.2f}"); results['would_delete_inst_snap'].append(sid)
                        else:
                            try: rds_client.delete_db_snapshot(DBSnapshotIdentifier=sid); results['deleted_inst_snap'].append(sid)
                            except ClientError as e: results['errors'].append(f"ISnapDelErr({sid}):{e}"); results['savings']-=sv
        except ClientError as e: results['errors'].append(f"DescISnapErr:{e}")
        try: # Cluster Snaps
            logger.info(f"[{region}] Checking clus snaps older than {cutoff.isoformat()} ({RDS_MANUAL_SNAPSHOT_RETENTION_DAYS} mins)")
            paginator=rds_client.get_paginator('describe_db_cluster_snapshots')
            for page in paginator.paginate(SnapshotType='manual',IncludeShared=False):
                 for snap in page.get('DBClusterSnapshots',[]):
                    sid,arn,stime=snap['DBClusterSnapshotIdentifier'],snap['DBClusterSnapshotArn'],snap.get('SnapshotCreateTime')
                    try: tags=rds_client.list_tags_for_resource(ResourceName=arn).get('TagList',[])
                    except ClientError: tags=[]
                    if is_excluded(tags): continue
                    if snap.get('Status')=='available' and stime and stime < cutoff:
                        sz=snap.get('AllocatedStorage',0); sz=sz if isinstance(sz,(int,float)) else 0
                        sv=sz*RDS_SNAPSHOT_PRICE_GB_MONTH; results['savings']+=sv
                        if DRY_RUN: logger.info(f"[DRY] Would del clus snap {sid}. Est ${sv:.2f}"); results['would_delete_clus_snap'].append(sid)
                        else:
                            try: rds_client.delete_db_cluster_snapshot(DBClusterSnapshotIdentifier=sid); results['deleted_clus_snap'].append(sid)
                            except ClientError as e: results['errors'].append(f"CSnapDelErr({sid}):{e}"); results['savings']-=sv
        except ClientError as e: results['errors'].append(f"DescCSnapErr:{e}")


    logger.info(f"--- Finished RDS Optimization in {region} ---")

    # --- Build Summary ---
    imc=len(results['would_modify_inst_ret']) if DRY_RUN else results['modified_inst_ret']
    cmc=len(results['would_modify_clus_ret']) if DRY_RUN else results['modified_clus_ret']
    isdc=len(results['would_delete_inst_snap']) if DRY_RUN else len(results['deleted_inst_snap'])
    csdc=len(results['would_delete_clus_snap']) if DRY_RUN else len(results['deleted_clus_snap'])
    ap="Would " if DRY_RUN else ""

    if imc>0: results['summary_lines'].append(f"{ap}modify ret for {imc} instance(s).")
    if cmc>0: results['summary_lines'].append(f"{ap}modify ret for {cmc} cluster(s).")
    if isdc>0: results['summary_lines'].append(f"{ap}delete {isdc} inst snapshot(s).")
    if csdc>0: results['summary_lines'].append(f"{ap}delete {csdc} clus snapshot(s).")
    if results['low_cpu_reported_inst']: results['summary_lines'].append(f"Found {len(results['low_cpu_reported_inst'])} low CPU instance(s): {results['low_cpu_reported_inst'][:5]}...")
    if not (imc or cmc or isdc or csdc or results['low_cpu_reported_inst']): results['summary_lines'].append("No RDS opt actions required.")
    if results['errors']: results['summary_lines'].append(f"Errors: {len(results['errors'])}")

    final_savings = max(0, results['savings'])
    results['summary_lines'].append(f"{'Est potential' if DRY_RUN else 'Achieved'} savings: ${final_savings:.2f} USD/month by RDS")
    return " | ".join(results['summary_lines']), final_savings


def optimize_nat_gateways(ec2_client, cloudwatch_client, region):
    """Report potentially idle NAT Gateways based on low traffic."""
    logger.info(f"--- Starting NAT Gateway Idle Reporting in {region} ---")
    if not ENABLE_NAT_GATEWAY_IDLE_REPORTING: return "NAT Gateway reporting disabled.", 0.0

    results = { "savings": 0.0, "errors": [], "summary_lines": [], "idle_reported_nat": [] }
    now_utc = datetime.now(timezone.utc)
    # Use DAYS for NAT idle check
    check_start_time = now_utc - timedelta(days=NAT_IDLE_CHECK_DAYS)
    logger.info(f"[{region}] Checking NAT GWs for traffic since {check_start_time.isoformat()} ({NAT_IDLE_CHECK_DAYS} days ago)")
    nat_monthly_cost = NAT_GW_PRICE_HOURLY * 24 * 30.44

    try:
        paginator = ec2_client.get_paginator('describe_nat_gateways')
        # Filter only available NAT gateways
        page_iterator = paginator.paginate(Filter=[{'Name': 'state', 'Values': ['available']}])

        for page in page_iterator:
            for nat in page.get('NatGateways', []):
                nat_id = nat['NatGatewayId']
                tags = nat.get('Tags', [])

                if is_excluded(tags):
                    logger.info(f"[{region}] Skipping excluded NAT Gateway {nat_id}")
                    continue

                try:
                    # Check BytesProcessed metric
                    metrics = cloudwatch_client.get_metric_statistics(
                        Namespace='AWS/NATGateway', MetricName='BytesProcessed',
                        Dimensions=[{'Name': 'NatGatewayId', 'Value': nat_id}],
                        StartTime=check_start_time, EndTime=now_utc,
                        Period=86400 * NAT_IDLE_CHECK_DAYS, # Total sum over the period
                        Statistics=['Sum'], Unit='Bytes'
                    )
                    total_bytes = sum(dp['Sum'] for dp in metrics['Datapoints'])

                    if total_bytes < NAT_BYTES_PROCESSED_THRESHOLD:
                        logger.info(f"[{region}] Found potentially idle NAT Gateway {nat_id} ({total_bytes / (1024**3):.2f} GB processed in last {NAT_IDLE_CHECK_DAYS} days).")
                        results['idle_reported_nat'].append(nat_id)
                        results['savings'] += nat_monthly_cost # Add potential hourly cost saving
                    else:
                        logger.debug(f"[{region}] NAT Gateway {nat_id} seems active ({total_bytes / (1024**3):.2f} GB processed).")

                except ClientError as e:
                    # Handle cases where metrics might not exist for a very new/unused NAT GW
                    logger.warning(f"[{region}] Could not get metrics for NAT Gateway {nat_id}: {e}. Skipping idle check.")
                    results['errors'].append(f"NAT Metric Err ({nat_id}): {e}")
                except Exception as e:
                     logger.error(f"[{region}] Unexpected error processing NAT GW {nat_id}: {e}")
                     results['errors'].append(f"NAT Proc Err ({nat_id}): {e}")

    except ClientError as e:
        logger.error(f"[{region}] Error describing NAT Gateways: {e}")
        results['errors'].append(f"Desc NAT GW Err: {e}")

    logger.info(f"--- Finished NAT Gateway Idle Reporting in {region} ---")

    # --- Build Summary ---
    if results['idle_reported_nat']:
        results['summary_lines'].append(f"Found {len(results['idle_reported_nat'])} potentially idle NAT Gateway(s): {results['idle_reported_nat'][:5]}...")
        results['summary_lines'].append("WARNING: Verify connectivity needs before deletion!")
    else:
        results['summary_lines'].append("No potentially idle NAT Gateways found.")

    if results['errors']: results['summary_lines'].append(f"Errors: {len(results['errors'])}")

    final_savings = max(0, results['savings'])
    savings_label = "Estimated potential" # Always potential
    results['summary_lines'].append(f"{savings_label} savings: ${final_savings:.2f} USD/month by NAT GW")
    return " | ".join(results['summary_lines']), final_savings


def optimize_security_groups(ec2_client, region):
    """Report potentially unused Security Groups (basic check)."""
    logger.info(f"--- Starting Unused Security Group Reporting in {region} ---")
    if not ENABLE_UNUSED_SECURITY_GROUP_REPORTING: return "Unused SG reporting disabled.", 0.0

    results = { "errors": [], "summary_lines": [], "unused_reported_sg": [] }
    # No direct savings calculated

    try:
        logger.info(f"[{region}] Describing all security groups...")
        all_sgs = {}
        paginator_sg = ec2_client.get_paginator('describe_security_groups')
        for page in paginator_sg.paginate():
            for sg in page.get('SecurityGroups', []):
                # Ignore default SGs, store others with basic info
                if sg.get('GroupName') != 'default':
                    all_sgs[sg['GroupId']] = {'Name': sg['GroupName'], 'InUse': False, 'Tags': sg.get('Tags', [])}

        logger.info(f"[{region}] Found {len(all_sgs)} non-default security groups. Checking associations...")

        # --- Check Associations (Can be slow and incomplete) ---
        # 1. Network Interfaces (covers Instances, Lambda VPC, ELB Interfaces, etc.)
        try:
            paginator_eni = ec2_client.get_paginator('describe_network_interfaces')
            for page in paginator_eni.paginate():
                for eni in page.get('NetworkInterfaces', []):
                    for group in eni.get('Groups', []):
                        if group['GroupId'] in all_sgs:
                            all_sgs[group['GroupId']]['InUse'] = True
            logger.debug(f"[{region}] Finished checking ENI associations.")
        except ClientError as e: results['errors'].append(f"SG Check ENI Err: {e}")

        # 2. Check EC2 Launch Templates (more thorough) - Potentially add later if needed
        # try:
        #     paginator_lt = ec2_client.get_paginator('describe_launch_template_versions')
        #     # This requires listing templates first, then versions - complex loop
        # except ClientError as e: results['errors'].append(f"SG Check LT Err: {e}")

        # --- Report Unused ---
        for sg_id, sg_info in all_sgs.items():
            if not sg_info['InUse']:
                 if not is_excluded(sg_info['Tags']): # Check exclusion tag
                      logger.info(f"[{region}] Found potentially unused Security Group: {sg_id} (Name: {sg_info['Name']})")
                      results['unused_reported_sg'].append(f"{sg_id}({sg_info['Name']})")
                 else:
                      logger.info(f"[{region}] Skipping excluded potentially unused SG: {sg_id}")

    except ClientError as e:
        logger.error(f"[{region}] Error describing Security Groups: {e}")
        results['errors'].append(f"Desc SG Err: {e}")
    except Exception as e: # Catch potential issues during association checks
         logger.error(f"[{region}] Unexpected error checking SG associations: {e}", exc_info=True)
         results['errors'].append(f"SG Assoc Check Err: {e}")


    logger.info(f"--- Finished Unused Security Group Reporting in {region} ---")

    # --- Build Summary ---
    if results['unused_reported_sg']:
        results['summary_lines'].append(f"Found {len(results['unused_reported_sg'])} potentially unused SG(s): {results['unused_reported_sg'][:5]}...")
        results['summary_lines'].append("WARNING: Verify dependencies thoroughly before deletion!")
    else:
        results['summary_lines'].append("No potentially unused non-default Security Groups found (basic check).")

    if results['errors']: results['summary_lines'].append(f"Errors: {len(results['errors'])}")

    return " | ".join(results['summary_lines']), 0.0 # No direct savings


# --- Reporting and Notification Helpers ---

def upload_report_to_s3(s3_client, bucket_name, report_key, report_content):
    """Uploads the report to S3 (HTML) and generates a pre-signed URL."""
    try:
        report_bytes = report_content.encode('utf-8')
        s3_client.put_object( Bucket=bucket_name, Key=report_key, Body=report_bytes, ContentType="text/html; charset=utf-8" )
        logger.info(f"Report uploaded to S3: s3://{bucket_name}/{report_key}")
        presigned_url = s3_client.generate_presigned_url( 'get_object', Params={'Bucket': bucket_name, 'Key': report_key}, ExpiresIn=604800 )
        logger.debug(f"Generated pre-signed URL: {presigned_url}")
        return presigned_url
    except ClientError as e: logger.error(f"Error uploading report to S3/generating URL: {e}"); return f"s3://{bucket_name}/{report_key}"
    except Exception as e: logger.error(f"Unexpected error during S3 report upload: {e}"); raise

def send_sns_notification(sns_client, topic_arn, subject, message):
    """Sends a notification to the specified SNS topic."""
    try:
        response = sns_client.publish(TopicArn=topic_arn, Subject=subject, Message=message)
        logger.info(f"Notification sent to SNS {topic_arn}. Msg ID: {response.get('MessageId')}")
    except ClientError as e: logger.error(f"Error sending SNS notification: {e}")
    except Exception as e: logger.error(f"Unexpected error sending SNS: {e}")


# --- Main Handler ---

def lambda_handler(event, context):
    """Main Lambda execution entry point."""
    # Initialize savings variables including new ones
    savings_totals = { "EC2": 0.0, "EBS": 0.0, "ELB": 0.0, "EIP": 0.0, "CloudWatch Logs": 0.0,
                       "RDS": 0.0, "S3": 0.0, "Lambda": 0.0, "EKS": 0.0, "NAT Gateway": 0.0,
                       "Security Group": 0.0 } # SG savings always 0
    all_regional_summaries = {} # Store text summaries per region/service

    report_bucket_name = os.environ.get("REPORT_BUCKET_NAME")
    sns_topic_arn = os.environ.get("SNS_TOPIC_ARN")
    if not report_bucket_name or not sns_topic_arn:
        error_message = f"Missing required ENV VAR(s): {'REPORT_BUCKET_NAME ' if not report_bucket_name else ''}{'SNS_TOPIC_ARN' if not sns_topic_arn else ''}".strip()
        logger.error(error_message)
        return {"statusCode": 500, "body": json.dumps({"error": error_message})}

    logger.info("--- Starting Cloud Infra Cost Optimizer ---")
    start_time = datetime.now(timezone.utc)
    logger.info(f"Timestamp: {start_time.isoformat()}")
    if DRY_RUN: logger.warning("DRY RUN mode enabled.")
    else: logger.warning("DRY RUN mode disabled. CHANGES WILL BE APPLIED.")

    regions_to_process = TARGET_REGIONS if TARGET_REGIONS else [DEFAULT_REGION]
    logger.info(f"Target regions: {regions_to_process}")

    all_regional_errors = {}

    # --- Loop through Regions ---
    for region in regions_to_process:
        logger.info(f"--- Processing Region: {region} ---")
        region_start_time = datetime.now(timezone.utc)
        region_errors = []
        region_summary_text = {} # Store text summaries per service

        try:
            session = boto3.Session(region_name=region)
            clients = { # Initialize all clients
                "ec2": session.client("ec2"), "elbv2": session.client("elbv2"),
                "cloudwatch": session.client("cloudwatch"), "logs": session.client("logs"),
                "rds": session.client("rds"), "s3": session.client("s3"),
                "lambda": session.client("lambda"), "eks": session.client("eks")
            }

            # Define service processing order & functions
            service_processing_map = {
                "EC2": (optimize_ec2, [clients["ec2"], clients["cloudwatch"], region]),
                "EBS": (optimize_ebs, [clients["ec2"], clients["cloudwatch"], region]),
                "ELB": (optimize_load_balancers, [clients["elbv2"], clients["cloudwatch"], region]),
                "EIP": (optimize_elastic_ips, [clients["ec2"], region]),
                "NAT Gateway": (optimize_nat_gateways, [clients["ec2"], clients["cloudwatch"], region]), 
                "Security Group": (optimize_security_groups, [clients["ec2"], region]), 
                "CloudWatch Logs": (optimize_cloudwatch_logs, [clients["logs"], region]),
                "CloudWatch Alarms": (report_cloudwatch_alarms, [clients["cloudwatch"], region]), # Reporting only
                "RDS": (optimize_rds, [clients["rds"], clients["cloudwatch"], region]),
                "S3": (optimize_s3, [clients["s3"], region]),
                "Lambda": (optimize_lambda_functions, [clients["lambda"], clients["cloudwatch"], region]), # Reporting only
                "EKS": (optimize_eks_clusters, [clients["eks"], region]), # Reporting only
            }

            # Execute functions dynamically
            for service_name, (func, args) in service_processing_map.items():
                try:
                    # Reporting functions might return only summary string
                    result = func(*args)
                    if isinstance(result, tuple) and len(result) == 2:
                        summary, savings = result
                        savings_totals[service_name] += savings
                    else: # Assumed to be reporting only function
                        summary = result
                    region_summary_text[service_name] = summary
                except Exception as e:
                    logger.error(f"[{region}] Error in {service_name} optimization: {e}", exc_info=True)
                    region_summary_text[service_name] = f"Error: {e}"
                    region_errors.append(f"{service_name}:{e}")

            all_regional_summaries[region] = region_summary_text # Store collected summaries

        except (ClientError, NoCredentialsError, PartialCredentialsError) as e:
            logger.error(f"!!! AWS Client/Credential error processing region {region}: {e}", exc_info=True)
            all_regional_summaries[region] = {"Error": f"AWS Client/Credential Error: {e}"}
            region_errors.append(f"Client/Credential Error: {e}")
        except Exception as e:
            logger.error(f"!!! Unexpected error processing region {region} setup: {e}", exc_info=True)
            all_regional_summaries[region] = {"Error": f"Setup Error: {e}"}
            region_errors.append(f"Setup Error: {e}")

        if region_errors: all_regional_errors[region] = region_errors
        region_end_time = datetime.now(timezone.utc)
        logger.info(f"--- Finished processing region {region}. Duration: {region_end_time - region_start_time} ---")

    # --- Aggregated Metrics ---
    total_regions_processed = len(regions_to_process)
    total_errors_count = sum(len(v) for v in all_regional_errors.values())
    total_savings = sum(max(0, v) for v in savings_totals.values()) # Sum non-negative savings

    # Prepare data for JS chart (ensure order matches labels)
    chart_labels = ["EC2", "EBS", "ELB", "EIP", "NAT GW", "SG", "CW Logs", "RDS", "S3", "Lambda", "EKS"]
    chart_values = [ max(0, savings_totals.get(label.replace("NAT GW","NAT Gateway").replace("SG","Security Group"), 0.0)) for label in chart_labels ] # Map labels correctly
    savings_data_for_js = {"labels": chart_labels, "values": chart_values}
    savings_json_str = json.dumps(savings_data_for_js)

    # --- Build HTML Report ---
    html_lines = [
        "<!DOCTYPE html><html lang='en'><head><meta charset='UTF-8'>",
        "<title>Cloud Infra Cost Optimizer Report</title>",
        "<script src='https://cdn.jsdelivr.net/npm/chart.js'></script>",
        "<style>body{font-family:system-ui,sans-serif;margin:20px;line-height:1.5;background-color:#f8f9fa;color:#212529}h1,h2,h3{color:#007bff;margin-top:1.5em;margin-bottom:0.5em}h1{text-align:center;border-bottom:2px solid #dee2e6;padding-bottom:10px}.meta-info{text-align:center;margin-bottom:2em;color:#6c757d}.region-summary{background-color:#fff;border:1px solid #dee2e6;border-radius:5px;padding:15px;margin-bottom:20px;box-shadow:0 1px 3px rgba(0,0,0,0.1)}.region-summary h3{color:#17a2b8;margin-top:0;border-bottom:1px solid #eee;padding-bottom:5px}.summary-section{margin-top:30px;padding:20px;background-color:#fff;border:1px solid #dee2e6;border-radius:5px}pre{background-color:#e9ecef;padding:10px;border:1px solid #ced4da;border-radius:4px;white-space:pre-wrap;word-wrap:break-word;font-size:0.9em;margin-top:5px;margin-bottom:10px;}strong{color:#495057}.notes{font-size:0.9em;color:#6c757d;margin-top:20px;border-top:1px solid #eee;padding-top:10px}.chart-container{max-width:800px;margin:20px auto;height:450px;}</style>", # Increased chart height slightly
        "</head><body>",
        "<h1>Cloud Infra Cost Optimizer Report</h1>",
        f"<div class='meta-info'><strong>Execution Time:</strong> {start_time.isoformat()}<br/><strong>DRY RUN Mode:</strong> {DRY_RUN}</div>",
        "<h2>Regional Details</h2>"
    ]
    if all_regional_summaries:
        for region, summaries in all_regional_summaries.items():
            html_lines.append(f"<div class='region-summary'><h3>Region: {region}</h3>")
            if "Error" in summaries: html_lines.append(f"<pre style='color: red;'><strong>Error:</strong> {summaries['Error']}</pre>")
            else:
                html_lines.append("<ul>")
                service_order = ["EC2", "EBS", "ELB", "EIP", "NAT Gateway", "Security Group", "CloudWatch Logs", "CloudWatch Alarms", "RDS", "S3", "Lambda", "EKS"]
                for service in service_order:
                    if service in summaries:
                        summary_text = summaries[service] if summaries[service] else "No actions/errors."
                        escaped_summary = summary_text.replace("&", "&").replace("<", "<").replace(">", ">")
                        html_lines.append(f"<li><strong>{service}:</strong><pre>{escaped_summary}</pre></li>")
                html_lines.append("</ul>")
            html_lines.append("</div>")
    else: html_lines.append("<p>No regions processed.</p>")

    html_lines.extend([
        "<div class='summary-section'><h2>Overall Summary</h2>",
        f"<p><strong>Total Regions Processed:</strong> {total_regions_processed}</p>",
        f"<p><strong>Total Errors Encountered:</strong> {total_errors_count}</p>"
    ])
    if total_errors_count > 0:
        html_lines.append("<p><strong>Errors Summary:</strong></p><ul>")
        for region, errors in all_regional_errors.items(): html_lines.append(f"<li>{region}: {len(errors)} error(s)</li>")
        html_lines.append("</ul>")

    html_lines.extend([
        "<h2>Savings Breakdown</h2>",
        "<div class='chart-container'><canvas id='savingsBarChart'></canvas></div>",
        f"<p style='text-align: center; font-size: 1.2em;'><strong>Total Estimated Savings: ${total_savings:.2f}</strong></p>",
        "</div>", # End summary-section
        "<div class='notes'>"
    ])
    if DRY_RUN: html_lines.append("<p>Note: Savings are estimated based on DRY RUN mode.</p>")
    # Add specific notes for services
    if any("CloudWatch Logs" in s and "Error" not in s["CloudWatch Logs"] for s in all_regional_summaries.values() if isinstance(s, dict)): html_lines.append("<p>Note: CloudWatch Logs savings reported as $0.00; actual savings vary.</p>")
    if any("Lambda" in s and "Error" not in s["Lambda"] for s in all_regional_summaries.values() if isinstance(s, dict)): html_lines.append("<p>Note: Lambda reports potentially idle functions ($0.00 savings reported).</p>")
    if any("EKS" in s and "Error" not in s["EKS"] for s in all_regional_summaries.values() if isinstance(s, dict)): html_lines.append("<p>Note: EKS savings estimate is for control plane cost of potentially unused clusters only. Verify manually.</p>")
    if any("NAT Gateway" in s and "Error" not in s["NAT Gateway"] for s in all_regional_summaries.values() if isinstance(s, dict)): html_lines.append("<p>Note: NAT GW savings estimate is for hourly cost of potentially idle gateways only. Verify manually.</p>")
    if any("Security Group" in s and "Error" not in s["Security Group"] for s in all_regional_summaries.values() if isinstance(s, dict)): html_lines.append("<p>Note: Unused Security Group check is basic and requires manual verification before deletion.</p>")
    html_lines.append("</div>")

    # Embedded JavaScript for Chart
    html_lines.append("<script>")
    html_lines.append(f"const savingsData = {savings_json_str};")
    html_lines.append("const ctxBar = document.getElementById('savingsBarChart').getContext('2d');")
    html_lines.append("new Chart(ctxBar, { type: 'bar', data: {")
    html_lines.append("  labels: savingsData.labels, datasets: [{")
    html_lines.append("    label: 'Estimated Monthly Savings ($)', data: savingsData.values,")
    
    html_lines.append("    backgroundColor: ['#D9534F', '#5BC0DE', '#F0AD4E', '#5CB85C', '#B084CC', '#7E827A', '#6E54D9', '#0275D8', '#F7AC49', '#FF9900', '#232F3E', '#8C8C8C'],")
    html_lines.append("    borderColor: '#fff', borderWidth: 1")
    html_lines.append("}]}, options: { indexAxis: 'y', scales: { x: { beginAtZero: true, title: { display: true, text: 'USD ($) per Month' } } }, responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false }, title: { display: true, text: 'Estimated Savings Breakdown by Service', font: { size: 16 } } } } });")
    html_lines.append("</script>")
    html_lines.append("</body></html>")
    html_content = "\n".join(html_lines)

    # --- Finalize and Upload Report ---
    report_url = f"s3://{report_bucket_name}/UNKNOWN_REPORT_KEY.html"
    try:
        s3_client_upload = boto3.client("s3")
        report_time_str = start_time.strftime('%Y-%m-%dT%H-%M-%SZ')
        report_key = f"{os.environ.get('REPORT_KEY_PREFIX', 'cost-optimizer-reports/')}{report_time_str}-report.html"
        report_url = upload_report_to_s3(s3_client_upload, report_bucket_name, report_key, html_content)
    except Exception as e: logger.error(f"Failed to upload report to S3: {e}", exc_info=True)

    # --- Send SNS Notification ---
    try:
        sns_client = boto3.client("sns")
        action_desc = 'DRY RUN' if DRY_RUN else 'ACTION TAKEN'
        sns_subject = f"Cost Optimizer Report ({action_desc}) - ${total_savings:.2f} Savings Est"
        sns_message = ( f"Optimizer execution completed.\n\nMode: {action_desc}\nTime: {start_time.isoformat()}\n"
                        f"Total Savings Est: ${total_savings:.2f}\nRegions: {total_regions_processed}, Errors: {total_errors_count}\n\n"
                        f"Report: {report_url}" )
        send_sns_notification(sns_client, sns_topic_arn, sns_subject, sns_message)
    except Exception as e: logger.error(f"Failed to send SNS notification: {e}", exc_info=True)

    end_time = datetime.now(timezone.utc)
    logger.info(f"--- Cloud Infra Cost Optimizer execution finished. Total Duration: {end_time - start_time} ---")

    return { "statusCode": 200, "body": json.dumps({ "message": f"Run complete. Report: {report_url}", "totalSavings": total_savings, "dryRun": DRY_RUN, "errors": total_errors_count }) }

# --- End of File ---